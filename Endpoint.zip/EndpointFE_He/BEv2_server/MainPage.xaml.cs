﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace BEv2_server
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        Dictionary<Button, string> ClickDict;

        public MainPage()
        {
            this.InitializeComponent();
            OnPageInit();
        }

        private void OnPageInit()
        {
            FEHostURLTB.Text = "http://localhost:8184"; //DevSkim: ignore DS137138
            HTMLHostURLTB.Text = "http://localhost:8184"; //DevSkim: ignore DS137138
            HTMLPathURLTB.Text = "/dummies/html2"; //DevSkim: ignore DS137138
            JSHostURLTB.Text = "http://localhost:8184"; //DevSkim: ignore DS137138
            JSPathURLTB.Text = "/dummies/js2"; //DevSkim: ignore DS137138

            ClickDict = new Dictionary<Button, string>();
        }

        private async void GetHTMLPageButton_Click(object sender, RoutedEventArgs e)
        {
            await LoadHTMLPage();
            await LoadJS();
        }

        private void UpdateHTMLPageButton_Click(object sender, RoutedEventArgs e)
        {
            UpdateWebPage();
        }

        private void StopServerButton_Click(object sender, RoutedEventArgs e)
        {
            HttpClient Client = new HttpClient();
            Client.GetAsync($"{FEHostURLTB.Text}/stop");
        }

        private async Task LoadHTMLPage()
        {
            HttpClient Client = new HttpClient();
            Uri uri = new Uri($"{FEHostURLTB.Text}/loadhtml?host={Uri.EscapeDataString(HTMLHostURLTB.Text)}&path={Uri.EscapeDataString(HTMLPathURLTB.Text)}");
            HttpResponseMessage result = await Client.GetAsync(uri);
            GetJsonAndCreateGUI(result);
        }

        private void GetJsonAndCreateGUI(HttpResponseMessage response)
        {
            if (response.IsSuccessStatusCode)
            {
                string guiJson = Task.Run(() => response.Content.ReadAsStringAsync()).Result;
                TextBlock tb = new TextBlock();
                try
                {
                    HTMLElement root = JsonConvert.DeserializeObject<HTMLElement>(guiJson);
                    WebGUIStackPanel.Children.Clear();
                    CreateGUI(root.children[1], WebGUIStackPanel);
                }
                catch (Exception)
                {
                    tb.Text = "Error parsing JSON";
                }
            }
        }

        /*
        string CreateGUIText(HTMLElement element)
        {
            string Text = "";
            Text += $"Type:{element.type}\nAttributes: ";
            if (element.attributes != null)
            {
                foreach (string key in element.attributes.Keys)
                {
                    Text += element.attributes[key];
                }
            }
            else
            {
                Text += "None";
            }

            Text += "\nChildren:\n";
            if (element.children != null)
            {
                for (int i = 0; i < element.children.Length; i++)
                {
                    Text += CreateGUI(element.children[i]);
                }
            }
            else
            {
                Text += "None";
            }
            return Text;
        }*/

        void CreateGUI(HTMLElement element, StackPanel sp)
        {
            FrameworkElement ele;
            switch (element.type)
            {
                case "button":
                    ele = new Button();
                    break;
                case "h1":
                    ele = new TextBlock();
                    break;
                case "textarea":
                    ele = new TextBox();
                    break;
                default:
                    ele = new StackPanel();
                    break;
            }

            ele.HorizontalAlignment = HorizontalAlignment.Left;
            ele.VerticalAlignment = VerticalAlignment.Top;

            string pcdata = "";
            string placeholderText = "";
            string clickFunc = "";

            if (element.attributes != null)
            {
                Thickness thickness = new Thickness();
                foreach (string key in element.attributes.Keys)
                {
                    switch (key)
                    {
                        case "Margin-Top":
                            thickness.Top = Convert.ToDouble(element.attributes["Margin-Top"]);
                            break;
                        case "Margin-Bottom":
                            thickness.Bottom = Convert.ToDouble(element.attributes["Margin-Bottom"]);
                            break;
                        case "Margin-Left":
                            thickness.Left = Convert.ToDouble(element.attributes["Margin-Left"]);
                            break;
                        case "Margin-Right":
                            thickness.Right = Convert.ToDouble(element.attributes["Margin-Right"]);
                            break;
                        case "Height":
                            ele.Height = Convert.ToDouble(element.attributes["Height"]);
                            break;
                        case "Width":
                            ele.Width = Convert.ToDouble(element.attributes["Width"]);
                            break;
                        case "PCDATA":
                            pcdata = element.attributes["PCDATA"];
                            break;
                        case "placeholder":
                            placeholderText = element.attributes["placeholder"];
                            break;
                        case "Click":
                            clickFunc = element.attributes["Click"];
                            break;
                        default:
                            break;
                    }
                }
                ele.Margin = thickness;
            }

            switch (element.type)
            {
                case "button":
                    Button x = (Button)ele;
                    x.Content = pcdata;
                    ClickDict.Add(x, clickFunc);
                    x.Click += HTMLButtonClick;
                    sp.Children.Add(x);
                    break;
                case "h1":
                    TextBlock tb = (TextBlock)ele;
                    tb.Text = pcdata;
                    sp.Children.Add(tb);
                    break;
                case "textarea":
                    TextBox txb = (TextBox)ele;
                    txb.PlaceholderText = placeholderText;
                    sp.Children.Add(txb);
                    break;
                default:
                    StackPanel childsp = (StackPanel)ele;
                    if (element.children != null)
                    {
                        for (int i = 0; i < element.children.Length; i++)
                        {
                            CreateGUI(element.children[i], childsp);
                        }
                    }
                    sp.Children.Add(childsp);
                    break;
            }
        }

        private void HTMLButtonClick(object sender, RoutedEventArgs e)
        {
            ClickDict.TryGetValue((Button)sender, out string funcName);
            HttpClient Client = new HttpClient();
            Uri uri = new Uri($"{FEHostURLTB.Text}/click?func={funcName}");
            HttpResponseMessage result = Task.Run(() => Client.GetAsync(uri)).Result;
            UpdateWebPage();
        }

        private async void UpdateWebPage()
        {
            HttpClient Client = new HttpClient();
            HttpResponseMessage result = await Client.GetAsync($"{FEHostURLTB.Text}/update");
            GetJsonAndCreateGUI(result);
        }

        private async Task LoadJS()
        {
            HttpClient Client = new HttpClient();
            Uri uri = new Uri($"{FEHostURLTB.Text}/loadjs?host={Uri.EscapeDataString(JSHostURLTB.Text)}&path={Uri.EscapeDataString(JSPathURLTB.Text)}");
            await Client.GetAsync(uri);
        }
    }

    class HTMLElement
    {
        public string type { get; set; }
        public Dictionary<string, string> attributes { get; set; }
        public HTMLElement[] children { get; set; }
    }
}
