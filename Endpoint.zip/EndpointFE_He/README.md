# Endpoint FE (Helium)

>NOTE: This frontend (FE) only supports DOMv2 BE-FE interface

This is the "Helium" (second) model of the Endpoint Framework's frontend and is an implementation of the Endpoint FE framework which is capable of being created in various techonologies and programming languages.

We use the `C#` PL with the UWP (Universal Windows Platform) app development framework to create and use the frontend.

## Install, build and development

1. To use the FE, you need to install the `Universal Windows Platform development` workload in Visual Studio 2019. Make sure you are on Windows 10 version 1903 or above.

2. You can then just open the `EndpointFE_He.sln` file in visual studio and run the app in the configuration mode you deem best (you may leave it as it is) by clicking the play (debug) button.

3. The default values in the UI which you see after running the python code match with the default values at the Backend, but beware to change the default values of the paths the nackend uses to access html and JS files as those have been written accoding to the developer's system and will not be the same on your system. Relative path support to backend will be arriving soon.

4. After launching the python UI, before connecting to the BE, make sure the BE is running. The BE (DOMv2) can be run using the instructions in the README of the BE.

## How does it work

It uses a special JSON based communication format over REST implemented by HTTP requests to the BE.

The obtained JSON is interpreted locally and rendered to GUI. There is no parsing other than just reading the json and rendering UI.

The JS functions are connected in such a way that the BE is called on instances like button click after which the UI is re-rendered to show the updated DOM.
