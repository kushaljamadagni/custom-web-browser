#include"..\..\include\HAL_DeviceDrivers.h"
#include"..\..\include\KernelSubModules.h"

//Right now all elements belongs to the main window since parenting of
//elements hasn't been implemented yet. But will be in the future,
//Keep an eye on @Enygmator on github!

/*
rules to follow CAML implementation of XML:
1. no spaces in between =�and "�i.e. height="10"�is correct but, width = "10"�is wrong
2. The file should contain no complex XML and no errors at all, otherwise, no warnings will be generated, and errors�will be output
3. there should be only one white space between tag name and attribute and between two attributes
4. there should no spaces between attributes/tag name and the greater than angular bracket��
5. Margin must have exactly 2 position in each value e.g. : Margin="20,30,04,56"
6. Each Property must begin with capital letters
*/

void APPGUIRenderer(char* XMLString)
{	
	Tag TagsArr[10];
	char tagCounter = 0;
	char attrCounter = 0;
	char* str = XMLString;
	parseTagBlock(str, TagsArr, &tagCounter, &attrCounter);
	RenderFrom(TagsArr, &tagCounter, &attrCounter);
}

void RenderFrom(Tag* tags, char* tagCounterPtr, char* attrCounterPtr)
{
	char Height[20] = "Height";
	char Width[20] = "Width";
	char Margins[20] = "Margin";
	char Thickness[20] = "Thickness";
	char Fill[20] = "Fill";
	char BorderFill[20] = "BorderFill";
	char Orientation[20] = "Orientation";
	char Length[20] = "Length";

	int ValHeight = 0;
	int ValWidth = 0;
	Margin ValMargin;
	int ValThickness = 0;
	int ValFill = 0;
	int ValBorderFill = 0;
	int ValOrientation = 0;
	int ValLength = 0;

	for (int i = 0; i < *tagCounterPtr; i++)
	{		
		for (int j = 0; j < tags[i].attrNos; j++)
		{
			char* prop = tags[i].attrs[j].Prop;
			char* Value = tags[i].attrs[j].value;
			if (StrCmp(prop, Height))
			{
				ValHeight = GetIntFromString(Value);
			}
			else if (StrCmp(prop, Width))
			{
				ValWidth = GetIntFromString(Value);
			}
			else if (StrCmp(prop, Margins))
			{
				int m[4]; //TODO: only double digit margin
				for (int k = 0; k < 4; k++)
				{
					char x[3];
					x[0] = Value[3 * k];
					x[1] = Value[(3 * k)+ 1];
					x[2] = '\0';
					m[k] = GetIntFromString(x);
				}
				ValMargin.Left = m[0];
				ValMargin.Top = m[1];
				ValMargin.Right = m[2];
				ValMargin.Down = m[3];
			}
			else if (StrCmp(prop, Thickness))
			{
				ValThickness = GetIntFromString(Value);
			}
			else if (StrCmp(prop, Fill))
			{
				ValFill = GetIntFromString(Value);
			}
			else if (StrCmp(prop, BorderFill))
			{
				ValBorderFill = 0;
				ValBorderFill = GetIntFromString(Value);
			}
			else if (StrCmp(prop, Orientation))
			{
				ValOrientation = GetIntFromString(Value);
			}
			else if (StrCmp(prop, Length))
			{
				ValLength = GetIntFromString(Value);
			}
		}

		char rect[20] = "rect";
		char line[20] = "line";

		if (StrCmp(tags[i].name, rect))
		{
			VBEColor fill = (VBEColor){ .Alpha = 0, .Red = (((ValFill / 65536) % 256)), .Green = (((ValFill / 256) % 256)), .Blue = (ValFill % 256) };
			VBEColor bfill = (VBEColor){ .Alpha = 0, .Red = (((ValBorderFill / 65536) % 256)), .Green = (((ValBorderFill / 256) % 256)), .Blue = (ValBorderFill % 256) };
			DrawRect(newRect(ValHeight, ValWidth, ValThickness, ValMargin, fill, bfill), true);
		}else if (StrCmp(tags[i].name, line))
		{
			VBEColor fill = (VBEColor){ .Alpha = 0, .Red = (((ValFill / 65536) % 256)), .Green = (((ValFill / 256) % 256)), .Blue = (ValFill % 256) };
			DrawLine(newLine(ValOrientation, ValLength, ValThickness, ValMargin, fill));
		}
	}
}

char* parseTagBlock(char* str, Tag* tags, char* tagCounterPtr, char* attrCounterPtr)
{
	char* lines = str;
	while(*lines != '\0')
	{
		if (*lines == '<') lines = TagManager(lines, tags, tagCounterPtr, attrCounterPtr);
		else lines++;
	}
	return lines;
}

char* TraverseTill(char* str, char ch)
{
	while (*(str++) != ch);
	return str; //returns next character after character encountered
}

char* TagManager(char* st, Tag* tags, char* tagCounterPtr, char* attrCounterPtr)
{
	//Check if comment
	char* str = st;
	str++;
	if(*str == '/') return str;
	if(*str == '!')
	{
		str++;
		if(*(str++) == '-')
		{
			if(*(str++) == '-')
			{
				str = CommentOut(str);
				str++;
				return str;
			}
		}
	}
	else if ((*str >= 'a' && *str <= 'z') || (*str >= 'A' && *str <= 'Z'))
	{
		int i = 0;
		while (*str != ' ' && *str != '>' && *str != '/')
		{
			tags[*tagCounterPtr].name[i] = *str;
			str++; i++;
		}
		tags[*tagCounterPtr].name[i] = '\0';
		tags[*tagCounterPtr].attrNos = 0;
		while (*str != '>' && *str != '/')
		{
			if(*str == ' ') str++;
			str = AttributeDiscover(str, tags, tagCounterPtr, attrCounterPtr);
		}
		if(*str == '>')
		{
			*tagCounterPtr = *tagCounterPtr + 1;
			str++;
			str = parseTagBlock(str, tags, tagCounterPtr, attrCounterPtr);
			return str;
		}
		if(*str == '/' && *(str+1) == '>') 
		{
			*tagCounterPtr = *tagCounterPtr + 1;
			str+=2; return str; 
		}
		if(*str == '<' && *(str+1) == '/') 
		{
			str = TraverseTill(str, '>');
			return str; 
		}
		*tagCounterPtr = *tagCounterPtr + 1;
		str++;
		return str;
	}
	return str;
}

char* AttributeDiscover(char* str, Tag* tags, char* tagCounterPtr, char* attrCounterPtr)
{
	int i = 0;
	while (*str != '=')
	{ 
		tags[*tagCounterPtr].attrs[tags[*tagCounterPtr].attrNos].Prop[i] = *str;
		str++; i++;
	}
	tags[*tagCounterPtr].attrs[tags[*tagCounterPtr].attrNos].Prop[i] = '\0';
	str+=2;
	i = 0;
	while(*str != '"')
	{
		tags[*tagCounterPtr].attrs[tags[*tagCounterPtr].attrNos].value[i] = *str;
		str++;i++;
	}
	tags[*tagCounterPtr].attrs[tags[*tagCounterPtr].attrNos].value[i] = '\0';
	str++;
	tags[*tagCounterPtr].attrNos++;
	*attrCounterPtr = *attrCounterPtr + 1;
	return str;
}

char* CommentOut(char* str)
{
	bool check = 0;
	while (check != 1)
	{        
		str = TraverseTill(str, '-');
		if(*(str++) == '-')
		{
			if(*(str++) == '>')
			{
				check = 1;
			}
		}
	}
	return str;
}