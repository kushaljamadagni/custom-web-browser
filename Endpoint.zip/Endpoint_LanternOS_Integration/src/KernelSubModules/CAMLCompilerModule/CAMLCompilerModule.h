typedef struct Attribute
{
    char Prop[20];
    char value[20];
} Attribute;

typedef struct Tag
{
    char attrNos;
    char name[20];
    Attribute attrs[10];
} Tag;

void APPGUIRenderer(char* XMLString);
char* parseTagBlock(char* str, Tag* tags, char* tagCounterPtr, char* attrCounterPtr);
char* TagManager(char* str, Tag* tags, char* tagCounterPtr, char* attrCounterPtr);
char* CommentOut(char* str);
char* TraverseTill(char* str, char ch);
char* AttributeDiscover(char* str, Tag* tags, char* tagCounterPtr, char* attrCounterPtr);
void RenderFrom(Tag* tags, char* tagCounterPtr, char* attrCounterPtr);