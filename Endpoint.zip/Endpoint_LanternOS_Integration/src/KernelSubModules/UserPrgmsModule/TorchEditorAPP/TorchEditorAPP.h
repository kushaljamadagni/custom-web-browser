void StartTorch();
void StartEditorInput();