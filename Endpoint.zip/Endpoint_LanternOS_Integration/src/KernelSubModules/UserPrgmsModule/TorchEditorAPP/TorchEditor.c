#include"..\..\..\include\HAL_DeviceDrivers.h"
#include"..\..\..\include\KernelSubModules.h"

void StartTorch()
{
	char xmlGUI[200] = "<rect Height=\"500\" Width=\"700\" Margin=\"40,20,40,60\" Fill=\"255\" BorderFill=\"16777215\" Thickness=\"1\"/>"
		"<line Length=\"1200\" Margin=\"40,50,00,00\" Fill=\"16777215\" Thickness=\"1\"/>";
	APPGUIRenderer(xmlGUI);
	TextBlock TB;
	TB.wrapWidth = 50;
	TB.pos = (PixelPosition){ .X = 42, .Y = 22 };
	TB.textColor = (VBEColor){ .Alpha = 0, .Red = 0xFF, .Green = 0xFF, .Blue = 0xFF };
	char titleText[40] = "F3 RETURN         TORCH EDITOR 3";
	StrCpy(TB.text, titleText);
	DrawText(&TB, (VBEColor) { .Alpha = 0, .Red = 0x00, .Green = 0x00, .Blue = 0xFF });
	StartEditorInput();
}

void StartEditorInput()
{
	TextBlock TB;
	TB.wrapWidth = 65;
	TB.pos = (PixelPosition){ .X = 42, .Y = 52 };
	TB.textColor = (VBEColor){ .Alpha = 0, .Red = 0xFF, .Green = 0xFF, .Blue = 0xFF };
	unsigned char ch = 0, t = 0;
	char makeKeys[55] = { 0,0,'1','2','3','4','5','6','7','8','9','0','-','=',8,9,'Q','W','E','R','T','Y','U','I',
		'O','P','[',']',0,0,'A','S','D','F','G','H','J','K','L',';','\'','`',0,'\\','Z','X','C','V','B','N','M',',','.','/',' ' };

	char x = 0;
	char placeHolder[20] = "ENTER HERE ";
	StrCpy(TB.text, placeHolder);
	DrawText(&TB, (VBEColor) { .Alpha = 0, .Red = 0x00, .Green = 0x00, .Blue = 0xFF });
	*(TB.text) = '\0';

	while (ch != (byte)61)
	{
		while ((ch = GetByteFromBuffer()) == 0);
		if (ch == (unsigned char)14)
		{
			StrTrim1(TB.text); //TODO: the backspace has to clear screen too
			DrawText(&TB, (VBEColor) { .Alpha = 0, .Red = 0x00, .Green = 0x00, .Blue = 0xFF });
		}
		else if (ch != 28 && ch != 29 && ch != 42 && ch < 54)
		{
			x = makeKeys[(int)ch];
			StrAppend(x, TB.text);
			DrawText(&TB, (VBEColor) { .Alpha = 0, .Red = 0x00, .Green = 0x00, .Blue = 0xFF });
		}
		else if (ch == 57)
		{
			x = makeKeys[54]; //SPACE CHARACTER
			StrAppend(x, TB.text);
			DrawText(&TB, (VBEColor) { .Alpha = 0, .Red = 0x00, .Green = 0x00, .Blue = 0xFF });
		}
	}
}