#include<stdbool.h>

typedef struct Margin
{
	int Left, Top, Right, Down;
} Margin;

typedef enum Orientation
{
	HORIZONTAL = 0,
	VERTICAL = 1
} Orientation;

typedef struct PixelPosition
{
	int X, Y;
} PixelPosition;

typedef bool OnlyMargin;

typedef struct Window
{
	int height, width;
	Margin margin;
} Window;

typedef struct Rect
{
	int height, width, thickness;
	Margin margin;
	VBEColor Fill, BorderFill;
} Rect;

typedef struct Line
{
	int Length, thickness;
	Orientation orientation;
	Margin margin;
	VBEColor Fill;
} Line;

Rect newRect(int height, int width, int thickness, Margin margin, VBEColor Fill, VBEColor BorderFill);
Line newLine(Orientation orientation, int length, int thickness, Margin margin, VBEColor fill);
void DrawLine(Line line);
void DrawRect(Rect rect, OnlyMargin isOnlyMargin);