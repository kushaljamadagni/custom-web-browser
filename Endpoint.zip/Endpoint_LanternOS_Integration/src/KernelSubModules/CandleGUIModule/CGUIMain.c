#include"..\..\include\KernelSubModules.h"
#include"..\..\include\HAL_DeviceDrivers.h"

void InitCGUI()
{
	/*int i = 0;
	while (i<200)
	{
		DrawRect(newRect(50, 40, 2, (Margin) { i,i,i,i },
			(VBEColor) { .Alpha = 0, .Red = 123, .Green = 0, .Blue = 217 },
			(VBEColor) { .Alpha = 0, .Red = 255, .Green = 255, .Blue = 255 }), true);
		i++;
	}*/
	//DrawRect(newRect(50, 40, 2, (Margin) { 30, 30, 30, 30 }, (VBEColor) { 0, 123, 0, 217 }, (VBEColor) { 0, 255, 255, 255 }), true);
}

__attribute__((interrupt)) void ShowErrorScreenIR(InterruptStackframe* ishandle)
{
	ClearVBEScreen((VBEColor) { 0x00, 0xFF, 0x00, 0x00 });
}

__attribute__((interrupt)) void ShowWarnScreenIR(InterruptStackframe* ishandle)
{
	__asm__ __volatile__("cli\n\t");
	int* video_memory = (int*)VBE_DISPI_LFB_PHYSICAL_ADDRESS;
	*video_memory = *video_memory ? 0x0 : 0xFFFFFF;
	SendEOI();
	__asm__ __volatile__("sti\n\t");
}
