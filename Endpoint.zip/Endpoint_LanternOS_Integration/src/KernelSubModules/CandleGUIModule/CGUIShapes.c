#include"..\..\include\KernelSubModules.h"
#include"..\..\include\HAL_DeviceDrivers.h"

Rect newRect(int height, int width, int thickness, Margin margin, VBEColor Fill, VBEColor BorderFill)
{
	return (Rect) { .height = height, .width = width, .thickness = thickness, .margin = margin, .Fill = Fill, .BorderFill = BorderFill};
}

Line newLine(Orientation orientation, int length, int thickness, Margin margin, VBEColor fill)
{
	return ((Line) {.Length = length, .thickness = thickness, .orientation = orientation, .margin = margin, .Fill = fill});
}

void DrawRect(Rect rect, OnlyMargin isOnlyMargin)
{
	if (isOnlyMargin)
	{
		DrawLine((Line) {
			.Length = (VBE_WIDTH - rect.margin.Right - rect.margin.Left ), .thickness = rect.thickness, .orientation = HORIZONTAL,
				.margin = (Margin){ .Left = rect.margin.Left, .Top = rect.margin.Top }, .Fill = rect.BorderFill
		});
		DrawLine((Line) {
			.Length = (VBE_WIDTH - rect.margin.Right - rect.margin.Left ), .thickness = rect.thickness, .orientation = HORIZONTAL,
				.margin = (Margin){ .Left = rect.margin.Left, .Top = (VBE_HEIGHT - rect.margin.Down - rect.thickness) }, .Fill = rect.BorderFill
		});
		DrawLine((Line) {
			.Length = (VBE_HEIGHT - rect.margin.Down - (2 * rect.thickness) - rect.margin.Top), .thickness = rect.thickness, .orientation = VERTICAL,
				.margin = (Margin){ .Left = rect.margin.Left, .Top = (rect.margin.Top + rect.thickness) }, .Fill = rect.BorderFill
		});
		DrawLine((Line) {
			.Length = (VBE_HEIGHT - rect.margin.Down - (2 * rect.thickness) - rect.margin.Top), .thickness = rect.thickness, .orientation = VERTICAL,
				.margin = (Margin){ .Left = (VBE_WIDTH - rect.margin.Right - rect.thickness), .Top = (rect.margin.Top + rect.thickness) }, .Fill = rect.BorderFill
		});
		DrawLine((Line) {
			.Length = (VBE_WIDTH - rect.margin.Right - rect.margin.Left - (2 * rect.thickness)),
			.thickness = (VBE_HEIGHT - rect.margin.Down - rect.margin.Top - (2 * rect.thickness)), .orientation = HORIZONTAL,
			.margin = (Margin){ .Left = (rect.margin.Left + rect.thickness), .Top = (rect.margin.Top + rect.thickness) },
			.Fill = rect.Fill
		});
	}
}

void DrawLine(Line line)
{
	int* vidMem = (int*)VBE_DISPI_LFB_PHYSICAL_ADDRESS;
	if (line.orientation)
	{
		for (int j = line.margin.Top; j < (line.Length + line.margin.Top); j++)
		{
			for (int i = line.margin.Left; i < (line.thickness + line.margin.Left); i++)
			{
				*(vidMem + (VBE_WIDTH * j) + i) = VBEColorToInt(line.Fill);
			}
		}
	}
	else
	{
		for (int j = line.margin.Top; j < (line.thickness + line.margin.Top); j++)
		{
			for (int i = line.margin.Left; i < (line.Length + line.margin.Left); i++)
			{
				*(vidMem + (VBE_WIDTH * j) + i) = VBEColorToInt(line.Fill);
			}
		}
	}
} //TODO: Write code to check PixelOutOfBounds