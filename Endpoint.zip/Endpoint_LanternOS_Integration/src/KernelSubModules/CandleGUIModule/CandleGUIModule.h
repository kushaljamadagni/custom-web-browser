typedef struct TextBlock
{
	char text[200];
	PixelPosition pos;
	VBEColor textColor;
	int wrapWidth;
} TextBlock;

void InitCGUI();
void DrawText(TextBlock* textBlock, VBEColor backgroundColor);
void ResetNumberOfCharsDrawnLastTime();
void ShowErrorScreenIR();
void ShowWarnScreenIR();