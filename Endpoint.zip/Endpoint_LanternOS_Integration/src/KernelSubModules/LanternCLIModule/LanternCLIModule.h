typedef struct CLI
{
	short* heightPtr;
	short* widthPtr;
	int* cursorPtr;
	Window hwnd;
} CLI;

CLI CreateCLIWindow(Window hwnd);
void StartCLIInput(CLI cli);