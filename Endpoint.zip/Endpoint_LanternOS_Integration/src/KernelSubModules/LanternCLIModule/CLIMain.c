#include"..\..\include\KernelRoot.h"

CLI CreateCLIWindow(Window hwnd)
{
	DrawRect(newRect(hwnd.height, hwnd.width, 1, hwnd.margin, (VBEColor) { 0, 0, 0, 0 }, (VBEColor) { 0, 255, 255, 255 }), true);
	return (CLI) {
		PutInMem((int*)0x100006, shortT, (GenericValue) { .shortVal = (short)((VBE_HEIGHT - hwnd.margin.Top - hwnd.margin.Down) / 24) }).shortPtr,
		PutInMem((int*)0x100004, shortT, (GenericValue) { .shortVal = (short)((VBE_WIDTH - hwnd.margin.Left - hwnd.margin.Right) / 18) }).shortPtr,
		PutInMem((int*)0x100008, intT, (GenericValue) { .intVal = 0 }).intPtr,
		hwnd
	};
}

void StartCLIInput(CLI cli)
{
	TextBlock TB;
	TB.wrapWidth = (int)((VBE_WIDTH - (cli.hwnd.margin.Left + cli.hwnd.margin.Right)) / 18);
	TB.pos = (PixelPosition){ .X = cli.hwnd.margin.Left, .Y = cli.hwnd.margin.Top };
	TB.textColor = (VBEColor){ .Alpha = 0, .Red = 0xFF, .Green = 0xFF, .Blue = 0xFF };
	unsigned char ch = 0, t = 0;
	char makeKeys[55] = { 0,0,'1','2','3','4','5','6','7','8','9','0','-','=',8,9,'Q','W','E','R','T','Y','U','I',
		'O','P','[',']',0,0,'A','S','D','F','G','H','J','K','L',';','\'','`',0,'\\','Z','X','C','V','B','N','M',',','.','/',' ' };

	char x = 0;
	char command[20] = "COMMAND 0  ";
	StrCpy(TB.text, command);
	DrawText(&TB, (VBEColor) { .Alpha = 0, .Red = 0x00, .Green = 0x00, .Blue = 0x00 });
	
	while (ch != (byte)61)
	{
		while ((ch = GetByteFromBuffer()) == 0);
		if (ch == (unsigned char)14)
		{
			StrTrim1(TB.text); //TODO: the backspace has to clear screen too
			DrawText(&TB, (VBEColor) { .Alpha = 0, .Red = 0x0, .Green = 0x0, .Blue = 0x0 });
		}
		else if (ch != 28 && ch != 29 && ch != 42 && ch < 54)
		{
			x = makeKeys[(int)ch];
			StrAppend(x, TB.text);
			DrawText(&TB, (VBEColor) { .Alpha = 0, .Red = 0x0, .Green = 0x0, .Blue = 0x0 });
		}
		else if(ch == 57)
		{
			x = makeKeys[54]; //SPACE CHARACTER
			StrAppend(x, TB.text);
			DrawText(&TB, (VBEColor) { .Alpha = 0, .Red = 0x0, .Green = 0x0, .Blue = 0x0 });
		}
	}
}

	/*
	{'ENTER	28},
	{'L,CTRL	29},
	{'L SHFT	42}
	{'R SHFT	54
	{'KP * 55
	{'L ALT	56
	{'SPACE	57
	{'CAPS	58
	{'F1	59
	{'F2	60
	{'F3	61
	{'F4	62
	{'F5	63
	{'F6	64
	{'F7	65
	{'F8	66
	{'F9	67
	{'F10	68
	{'NUM	69
	{'SCROLL	70
	{'KP 7	71
	{'KP 8	72
	{'KP 9	73
	{'KP - 74
	{'KP 4	75
	{'KP 5	76
	{'KP 6	77
	{'KP + 78
	{'KP 1	79
	{'KP 2	80
	{'KP 3	81
	{'KP 0	82
	{'KP .	83
	{'F11	87
	{'F12	88
	}
	*/