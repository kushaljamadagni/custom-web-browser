#include"..\..\include\KernelSubModules.h"
#include"..\..\include\HAL_DeviceDrivers.h"

void InitializeCGATextVideoDriver()
{
	ClearCGAScreen(VGA_BLUE);
	InitializeCursor();
}

void InitializeBGAModeVideoDriver()
{
	if (!VerifyBGAVersion()) return;
	InitializeBGA_LFB(1280, 720, VBE_DISPI_BPP_32);
	ClearVBEScreen((VBEColor) { .Alpha = 0, .Red = 243, .Green = 73, .Blue = 0 });
}

void InitInterrupts()
{
	extern void ShowWarnScreenIR();
	extern void ShowErrorScreenIR();
	for (int i = 0; i < 32; i++)
	{
		AddTrapGate((byte)i, ShowErrorScreenIR, (TrapGate) { .TGPL = RING_0, .tg_16or32 = TGBITS_32 });
	}
	for (int i = 32; i < 48; i++)
	{
		AddInterrupt((byte)i, ShowWarnScreenIR, (Interrupt) { .IDPL = RING_0, .id_16or32 = IDBITS_32 });
	}
	AddTrapGate((byte)6, ShowWarnScreenIR, (TrapGate) { .TGPL = RING_0, .tg_16or32 = TGBITS_32 });
	int* time = (int*)0x100014;
	*time = 0;
	time = (int*)0x100018;
	*time = 0;
	extern void AddByteToBufferIR(InterruptStackframe * ishandle);
	extern void TimeManager(InterruptStackframe * ishandle);
	extern void UpdateCursorDataIR(InterruptStackframe * ishandle);
	AddInterrupt(48, &AddByteToBufferIR, (Interrupt) { .IDPL = RING_0, .id_16or32 = IDBITS_32 });
	AddInterrupt((32 + Keyboard), &AddByteToBufferIR, (Interrupt) { .IDPL = RING_0, .id_16or32 = IDBITS_32 });
	AddInterrupt((32 + Mouse), UpdateCursorDataIR, (Interrupt) { .IDPL = RING_0, .id_16or32 = IDBITS_32 });
	AddInterrupt(32, TimeManager, (Interrupt) { .IDPL = RING_0, .id_16or32 = IDBITS_32 });
	LoadIDTR();
}

void InitPIC()
{
	byte a1, a2;
	a1 = asmInByte(PrimPICIMRNDataPort);
	a2 = asmInByte(SecPICIMRNDataPort);

	InitializeControlWord1(true, false, false, true);
	InitializeControlWord2(32, 40);
	InitializeControlWord3((byte)2);
	InitializeControlWord4(true, false, false, false, false);

	asmOutByte(PrimPICIMRNDataPort, a1);
	asmOutByte(SecPICIMRNDataPort, a2);

	asmOutByte(0x21, 0xF8);
	asmOutByte(0xa1, 0xEF);
}

void InitPIT()
{
	InitializePIT((short)100, PITMode2_RateGenerator, PIT_Counter0, ReadLSBthenMSB, false);
}