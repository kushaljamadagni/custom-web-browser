void InitializeCGATextVideoDriver();
void InitializeBGAModeVideoDriver();
void InitInterrupts();
void InitPIC();
void InitPIT();