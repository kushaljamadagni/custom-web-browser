//BOOTLOAD STAGE 1 File
__asm__(".code16");

char logoString[] = "Lantern OS\n\r";

void DispString(char *str)
{
	while (*str)
	{
		__asm__ __volatile__("int $0x10\n" : : "a"(0x0E00 | *str));
		str++;
	}
}

void bootloader_main(void)
{
	__asm__ __volatile__("int $0x10\n" : : "a"(0x03)); //clear screen
	DispString(logoString);
	DispString("Stage 1 bootloader\n\rPress any key to start stage 2 ...\n\r");

	__asm__ __volatile__(
		".intel_syntax noprefix		\n\t"		//Chnage to intel syntax
		"mov		ah, 0			\n\t"		//reset floppy disk function
		"int		0x13			\n\t"		//call BIOS
		/*
		"jnc		NoError1		\n\t"
		"call	DiskError			\n\t"
		"cli						\n\t"
		"hlt						\n\t"
		"NoError1:					\n\t"
		*/
		".att_syntax noprefix		\n\t"		//change to AT&T syntax 
	);

	__asm__ __volatile__(
		"mov	$0x07E0,	%%ax	\n\t"	// we are going to read sector to into address 0x1000:0
		"mov	%%ax,		%%es	\n\t"	// 
		"mov	$0x0000,	%%bx	\n\t"	// 
		: : : "memory");
	__asm__ __volatile__(" int	$0x13 \n\t": : "a"((0x02 * 0x100) | 0x0003), "c"((0x0000 * 0x100) | 0x0010), "d"((0x0001 * 0x100) | 0x0000) : "memory");

	/*
	"jnc		NoError1		\n\t"
	"call	DiskError			\n\t"
	"cli						\n\t"
	"hlt						\n\t"
	"NoError1:					\n\t"
	*/
}

void DiskError()
{
	DispString("Error in resetting head of/reading Disk");
}

//TODO: Figure out why error checking is not working/