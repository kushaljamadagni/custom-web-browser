#include"..\include\GenLib.h"

typedef enum GenericDataType GenericDataType;
typedef union GenericValue GenericValue;
typedef union MemPtr MemPtr;
typedef struct VBEColor VBEColor;
typedef char byte;

void BochsBreakHere(void)
{
	__asm__ __volatile__("xchg %bx, %bx");
	return;
}

MemPtr PutInMem(int* MemLoc, GenericDataType GDataType, GenericValue GValue)
{
	MemPtr retPtr;
	switch (GDataType)
	{
	case charT:
		retPtr.charPtr = (char*)MemLoc;
		*(retPtr.charPtr) = GValue.charVal;
		break;
	case shortT:
		retPtr.shortPtr = (short*)MemLoc;
		*(retPtr.shortPtr) = GValue.shortVal;
		break;
	case intT:
		retPtr.intPtr = (int*)MemLoc;
		*(retPtr.intPtr) = GValue.intVal;
		break;
	}
	return retPtr;
}

GenericValue GetFromMem(int* MemLoc, GenericDataType GDataType)
{
	GenericValue retVal;
	switch (GDataType)
	{
	case charT:
		retVal.charVal = *((char*)MemLoc);
		break;
	case shortT:
		retVal.shortVal = *((short*)MemLoc);
		break;
	case intT:
		retVal.intVal = *((int*)MemLoc);
		break;
	}
	return retVal;
}

void asmOutWord(short dx_Addr, short ax_Value)
{
	__asm__ __volatile__(
	".intel_syntax noprefix\n\t"
	"out dx, ax\n\t"
	".att_syntax noprefix\n\t"
	: : "d"(dx_Addr), "a"(ax_Value) : "memory"
	);
}

short asmInWord(short dx_Addr)
{
	short Value;
	__asm__ __volatile__("in %%dx, %0\n\t" : "=r"(Value) : "d"(dx_Addr) : "memory");
	return Value;
}

int VBEColorToInt(VBEColor Color)
{
	return (int)((0x1000000 * Color.Alpha) + (0x10000 * Color.Red) + (0x100 * Color.Green) + (Color.Blue));
}

byte asmInByte(short Addr)
{
	byte Value;
	__asm__ __volatile__("in %1, %0\n\t" : "=a"(Value) : "Nd"(Addr));
	return Value;
}

void asmOutByte(short Addr, byte Value)
{
	__asm__ __volatile__( "out %0, %1\n\t" : : "a"(Value), "Nd"(Addr));
}

void PressAnyKeyToContinue()
{
	byte test = 0;
	while (((test = asmInByte(0x64)) & (byte)1) == 0); //wait for input key
	asmInByte(0x60);
	while (((test = asmInByte(0x64)) & (byte)1) != 0) asmInByte(0x60); //wait for input buffer to empty out
}

//TODO: relocate these functions:
byte StrCmp(char* st1, char* st2) //TODO: make this return bool
{
	char* str1 = st1;
	char* str2 = st2;
	while ((*str1 != '\0') && (*str2 != '\0'))
	{
		if (*str1 != *str2) return 0;
		str1++;
		str2++;
	}
	if ((*str1 == '\0') && (*str2 == '\0'))
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

int GetIntFromString(char* str)
{
	char* st = str;
	int x = 0;
	while (*st)
	{
		x = (x * 10) + (((int)(*st)) - 48);
		st++;
	}
	return x;
}

void GetStringFromInt(char* str, int Value)
{
	char* st = str;
	int x = Value;
	while (x != 0)
	{
		*st = (char)((x % 10) + 48);
		x = (int)(x / 10);
		st++;
	}
}

void StrCpy(char* to, char* from)
{
	char* fromStr = from;
	char* toStr = to;
	while (*fromStr != '\0')
	{
		*toStr = *fromStr;
		fromStr++;
		toStr++;
	}
	*toStr = '\0';
}

void StrAppend(char chr, char* str)
{
	char* st = str;
	while (*st != '\0') st++;
	*st = chr;
	st++;
	*st = '\0';
}

void StrTrim1(char* str)
{
	char* st = str;
	while (*st != '\0') st++;
	*st = '\0';
	*(st - 1) = '\0';
}