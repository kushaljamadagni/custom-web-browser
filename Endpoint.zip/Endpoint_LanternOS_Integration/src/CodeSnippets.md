### 1.Boilerplate code for inline assembly in att syntax:
```C
__asm__ __volatile__(
	".intel_syntax noprefix\n\t"
	"\n\t"
	".att_syntax noprefix\n\t"
	);
```
### 2. This is code to read from floppy disk
```asm
	xor		ax, ax			# We want a segment of 0 for DS for this question
	mov		ds, ax			# Set AX to appropriate segment value for your situation
	mov		es, ax			# In this case we'll default to ES=DS
	mov		bx, 0x8400		# Stack segment can be any usable memory
	mov		ss, bx			# This places it with the top of the stack @ 0x80000.
	mov		sp, ax			# Set SP = 0 so the bottom of stack will be @ 0x8FFFF
	cld						#Set the direction flag to be positive direction
	
	#RESET DISK READ HEAD
	mov		ah, 0			# reset floppy disk function
	mov		dl, 0			# The floppy drive number is provided by BOCHS. don't change it
	int		0x13			# call BIOS

	#READ DISK
	mov		ax, 0x07E0		# we are going to read sector to into address
	mov		es, ax			# 
	mov		bx, 0x0000		# 
	mov		ah, 0x02		# read floppy sector function
	mov		al, 1			# number of sectors to read
	mov		ch, 0			# track/cylinder number
	mov		cl, 2			# start sector to read
	mov		dh, 0			# head number
	mov		dl, 0			# drive number is pre-loaded into by BIOS
	int		0x13		
```