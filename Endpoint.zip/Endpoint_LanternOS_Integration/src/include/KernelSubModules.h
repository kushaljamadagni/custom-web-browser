#pragma once
#include<stdbool.h>
#include"GenLib.h"
#include"..\KernelSubModules\PreKernelModule\PreKernelModule.h"
#include"..\KernelSubModules\CandleGUIModule\CGUIShapes.h"
#include"..\KernelSubModules\CandleGUIModule\CandleGUIModule.h"
#include"..\KernelSubModules\LanternCLIModule\LanternCLIModule.h"
#include"..\KernelSubModules\CAMLCompilerModule\CAMLCompilerModule.h"
//USER PROGRAMS:
#include"..\KernelSubModules\UserPrgmsModule\TorchEditorAPP\TorchEditorAPP.h"
//This should actually execute user programs, not contain the app itself