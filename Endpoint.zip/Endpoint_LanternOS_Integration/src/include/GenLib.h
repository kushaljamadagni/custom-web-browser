#pragma once

typedef char byte;

typedef enum GenericDataType
{
	charT,
	shortT,
	intT
} GenericDataType;

typedef union GenericValue
{
	char  charVal;
	short shortVal;
	int   intVal;
} GenericValue;

typedef union MemPtr
{
	char*  charPtr;
	short* shortPtr;
	int*   intPtr;
} MemPtr;

typedef enum Register
{
	al,	ah, bl, bh, cl, ch, dl, dh, ax, bx, cx, dx, eax, ebx, ecx, edx, si, di, esi, edi
} Register;

typedef struct VBEColor
{
	int Alpha, Red, Green, Blue;
} VBEColor;

MemPtr PutInMem(int* MemLoc, GenericDataType GDataType, GenericValue GValue);
GenericValue GetFromMem(int* MemLoc, GenericDataType GDataType);
void BochsBreakHere(void);
short asmInWord(short dx_Addr);
void asmOutWord(short dx_Addr, short ax_Value);
byte asmInByte(short dx_Addr);
void asmOutByte(short Addr, byte Value);
void PressAnyKeyToContinue();
int VBEColorToInt(VBEColor Color);

byte StrCmp(char* st1, char* st2);
int GetIntFromString(char* str);
void GetStringFromInt(char* str, int Value);
void StrCpy(char* to, char* from);
void StrAppend(char chr, char* str);
void StrTrim1(char* str);