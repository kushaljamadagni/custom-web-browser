1. There will be provision for 224 files on the FAT floppy
and `9*512/1.5 = 3072` cluster entries in the FAT. (with first 2 occupied)


|section|Start sector (LBA)|sect size|
|-----|----|----|
|boot sector| 0 |1|
|FAT1|1|9|
|FAT2|10|9|
|root dir|19|14/224 entries|
|The file system|||
|BLDRS2|33|3|
|Kernel|36|58|


### x86 Real Mode Memory Map

General x86 Real Mode Memory Map:

|Memory Locations | Used for|
|---------|-------|
|0x00000000 - 0x000003FF| Real Mode Interrupt Vector Table|
|0x00000400 - 0x000004FF| BIOS Data Area|
|0x00000500 - 0x00007BFF| Unused|
|0x00007C00 - 0x00007DFF| Our Bootloader|
|0x00007E00 - 0x0009FFFF| Unused|
|0x000A0000 - 0x000BFFFF| Video RAM (VRAM) Memory|
|0x000B0000 - 0x000B7777| Monochrome Video Memory|
|0x000B8000 - 0x000BFFFF| Color Video Memory|
|0x000C0000 - 0x000C7FFF| Video ROM BIOS|
|0x000C8000 - 0x000EFFFF| BIOS Shadow Area|
|0x000F0000 - 0x000FFFFF| System BIOS|

Our Default PAGE SYSTEM:

>stuff to come here soon

WE SHALL STORE:  
KEYBOARD BUFFER AT: 16MB RAM, size 1 MB
>SCREEN DUPLICATE BUFFER AT: 15 MB ,size 1 MB (arriving soon)

## RAM Structure

|Memory Locations (0x)| Used for | Size|
|---------|-------|-------|
|20 0000 (2MB) - 20 0800| PMode Interrupt Vector Table|2 KB|

>This table is incomplete, search for all functions using 
>putInMem and add to this table.
