//BOOTLOAD STAGE 2 File
__asm__ (".code16");

#include"Floppy_SM.c"

//Clears the screen
void ClearScreen()
{
	__asm__ __volatile__("int $0x10\n" : : "a"(0x03)); //clear screen
}

//Displays String to the screen and updates hardware cursor
void DispString(char* str)
{
	while (*str)
	{
		__asm__ __volatile__("int $0x10\n" : : "a"(0x0E00 | *str));
		str++;
	}
}

void BLDRS2_OnLoad(void)
{
	DispString("Stage 2 has successfully loaded\n\r");
}

void LoadKernel()
{
	LBASector readFromLBASector;
	ResetFloppyReadHead();
	setLBAreadSector(&readFromLBASector ,0x0024);
	ReadLBAFloppyA(0x0860, 0x0000, 0x003C, &readFromLBASector); //TODO: there seems to be some kind of error if the number of sectors read goes beyond 0x003C
	DispString("Kernel has been loaded\n\r");
}

void OnGDTTable()
{
	DispString("Press any key to Enter PMode (LOS Pre-Kernel)\n\r");
}
//TODO: use stack and see what happens to push ebx ; pop edi if ebx contains a string. i.e. inc edi changes edi, or 
//updates happen in the stack or whatever
//TODO: learn accessing variables b/w asm and C
//TODO: extern BPB initfunction.