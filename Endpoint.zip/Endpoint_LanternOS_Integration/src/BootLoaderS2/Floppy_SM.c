__asm__(".code16");

typedef struct LBASector
{
	short head, track, sector;
} LBASector;

//BPB (BIOS Parameter Block)
char	 bpbOEM[] = "LOSV1   ";
short    bpbBytesPerSector = 512;
char     bpbSectorsPerCluster = 1;
short    bpbReservedSectors = 1;
char     bpbNumberOfFATs = 2;
short    bpbRootEntries = 224;
short    bpbTotalSectors = 2880;
char     bpbMedia = 0xf0;
short    bpbSectorsPerFAT = 9;
short    bpbSectorsPerTrack = 18;
short    bpbHeadsPerCylinder = 2;
int      bpbHiddenSectors = 0;
int      bpbTotalSectorsBig = 0;
char     bsDriveNumber = 0;
char     bsUnused = 0;
char	 bsExtBootSignature = 0x29;
int		 bsSerialNumber = 0xa0a1a2a3;
char	 bsVolumeLabel[] = "LOSV1FLOPPY";
char	 bsFileSystem[] = "FAT12   ";

//Sets the CHS of a sector's LBA address to be read by read LBA
void setLBAreadSector(LBASector* readFromLBASector, short startSector)
{
	//LBA starts from sector 0
	short    bpbSectorsPerTrack = 18;
	short    bpbHeadsPerCylinder = 2;
	//TODO: global variables are not being read in properly or something else is happening (it works fine in kernel)

	readFromLBASector->sector = (startSector % bpbSectorsPerTrack) + 1;
	readFromLBASector->track = startSector / (bpbSectorsPerTrack * bpbHeadsPerCylinder);
	readFromLBASector->head = (startSector / bpbSectorsPerTrack) % bpbHeadsPerCylinder;
}

//Sets the CHS of a sector's LBA address to be read by read LBA
short ResetFloppyReadHead()
{
	short success = 1;
	__asm__ __volatile__(
		".intel_syntax noprefix		\n\t"		//Chnage to intel syntax
		"mov		ah, 0			\n\t"		//reset floppy disk function
		"int		0x13			\n\t"		//call BIOS
		".att_syntax noprefix		\n\t"		//change to AT&T syntax 
	);
	//TODO: Check Carry flag and handle error is set if there was an error, jump to .Error
	return success; //1 for successful execution, 0 for unsuccessful execution
}

//This function resets the floppy read head
short ReadCHSFloppyA(short writeToSegment, short writeToOffset, short numberOfSectorsToRead, short headNumber, short trackNumber, short startSector)
{
	short success = 1;
	__asm__ __volatile__(
		"mov	%[writeToSegment],			%%ax	\n\t"	// we are going to read sector to into address 0x1000:0
		"mov	%%ax,						%%es	\n\t"	// 
		"mov	%[writeToOffset],			%%bx	\n\t"	// 
		: : [writeToSegment] "m"(writeToSegment), [writeToOffset] "m"(writeToOffset) : "memory");
	//TODO: Check Carry flag and handle error is set if there was an error, jump to .Error
	__asm__ __volatile__(" int	$0x13 \n\t": : "a"((0x02 * 0x100) | numberOfSectorsToRead), "c"((trackNumber * 0x100) | startSector), "d"((headNumber * 0x100) | 0x0000) : "memory");
	return success; //1 for successful execution, 0 for unsuccessful execution
}

//Reads from floppy with input sector format as LBA
short ReadLBAFloppyA(short writeToSegment, short writeToOffset, short numberOfSectorsToRead, LBASector* readFromLBASector)
{
	__asm__ __volatile__(
		"mov	%[writeToSegment],			%%ax	\n\t"	// we are going to read sector to into address 0x1000:0
		"mov	%%ax,						%%es	\n\t"	// 
		"mov	%[writeToOffset],			%%bx	\n\t"	// 
		: : [writeToSegment] "m"(writeToSegment), [writeToOffset] "m"(writeToOffset) : "memory");
	__asm__ __volatile__(" int	$0x13 \n\t": : "a"((0x02 * 0x100) | numberOfSectorsToRead), "c"((readFromLBASector->track * 0x100) | readFromLBASector->sector), "d"((readFromLBASector->head * 0x100) | 0x0000) : "memory");
	return 1;
}