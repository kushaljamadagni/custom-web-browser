//This address must be obtained from the first base address of the PCI buffer
#define VBE_DISPI_LFB_PHYSICAL_ADDRESS  0xE0000000
#include<stdbool.h>

static const int VBE_WIDTH = 1280; //TODO: make global variables modifiable
static const int VBE_HEIGHT = 720;

typedef struct VBEColor VBEColor;

typedef enum vga_color {
	VGA_BLACK = 0,
	VGA_BLUE = 1,
	VGA_GREEN = 2,
	VGA_CYAN = 3,
	VGA_RED = 4,
	VGA_MAGENTA = 5,
	VGA_BROWN = 6,
	VGA_LIGHT_GREY = 7,
	VGA_DARK_GREY = 8,
	VGA_LIGHT_BLUE = 9,
	VGA_LIGHT_GREEN = 10,
	VGA_LIGHT_CYAN = 11,
	VGA_LIGHT_RED = 12,
	VGA_LIGHT_MAGENTA = 13,
	VGA_LIGHT_BROWN = 14,
	VGA_WHITE = 15,
} VgaColor;

typedef enum BPP
{
	VBE_DISPI_BPP_4  = 0x04,
	VBE_DISPI_BPP_8  = 0x08,
	VBE_DISPI_BPP_15 = 0x0F,
	VBE_DISPI_BPP_16 = 0x10,
	VBE_DISPI_BPP_24 = 0x18,
	VBE_DISPI_BPP_32 = 0x20,
} BPP;

void InitializeCursor(void);
void ClearCGAScreen(VgaColor ClearToColor);
void PrintToTerminalAtCursor(char* data, VgaColor TextColor, VgaColor BckGrndColor);
void PrintToTerminalAt(char* data, VgaColor TextColor, VgaColor BckGrndColor, byte x, byte y);

void InitializeBGA_LFB(int X_Resolution, int Y_Resolution, BPP BytesPerPixel);
bool VerifyBGAVersion();
void ClearVBEScreen(VBEColor ClearToColor);