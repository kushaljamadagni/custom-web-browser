#include"..\..\include\GenLib.h"
#include"..\..\include\HAL_DeviceDrivers.h"

static const byte VGA_WIDTH = 80;
static const byte VGA_HEIGHT = 25;

void InitializeCursor(void)
{
	PutInMem((int*)0x100000, shortT, (GenericValue){ .shortVal = 0 });
}

void ClearCGAScreen(VgaColor ClearToColor)
{
	char* video_memory = (char*)0xb8000;
	for (int i = 0; i < VGA_HEIGHT; i++)
	{
		for (int j = 0; j < VGA_WIDTH; j++)
		{
			*(video_memory + (2 * ((i * VGA_WIDTH) + j))) = (char) ' ';
			*(video_memory + (2 * ((i * VGA_WIDTH) + j)) + 1) = (ClearToColor << 4) | VGA_WHITE;
		}
	}
}

void PrintToTerminalAtCursor(char* data, VgaColor TextColor, VgaColor BckGrndColor)
{
	short cursor = GetFromMem((int*)0x100000, shortT).shortVal;
	char* dataPtr = data;
	byte* video_memory = (byte*)0xb8000;
	video_memory += (2 * cursor);

	while (*dataPtr != '\0')
	{
		if (*dataPtr == '\n')
		{
			video_memory += ((byte)2 * VGA_WIDTH);
		}
		else if (*dataPtr == '\r')
		{
			video_memory -= ((int)(video_memory - 0xb8000) % ((byte)2 * VGA_WIDTH));
		}
		else
		{
			*(video_memory++) = *dataPtr;
			*(video_memory++) = (BckGrndColor << 4) | TextColor;
		}
		dataPtr++;
	}
	cursor = (video_memory - (byte*)0xb8000) / 2;
	PutInMem((int*)0x100000, shortT, (GenericValue) { .shortVal = cursor });
	__asm__ __volatile__("call setCursor"::"b"(cursor));
}

void PrintToTerminalAt(char* data, VgaColor TextColor, VgaColor BckGrndColor, byte x, byte y)
{
	char* dataPtr = data;
	byte* video_memory = (byte*)0xb8000;
	if (y >= VGA_HEIGHT || x >= VGA_WIDTH) return;
	video_memory = video_memory + (2 * y * VGA_WIDTH) + 2 * x;

	while (*dataPtr != '\0')
	{
		if (*dataPtr == '\n')
		{
			video_memory += ((byte)2 * VGA_WIDTH);
		}
		else if(*dataPtr == '\r')
		{
			video_memory -= ((int)(video_memory - 0xb8000) % ((byte)2 * VGA_WIDTH));
		}
		else
		{
			*(video_memory++) = *dataPtr;
			*(video_memory++) = (BckGrndColor << 4) | TextColor;
		}
		dataPtr++;
	}
}