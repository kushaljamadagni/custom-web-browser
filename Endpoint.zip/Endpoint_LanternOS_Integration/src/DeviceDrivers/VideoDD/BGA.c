#include"..\..\include\GenLib.h"
#include"..\..\include\HAL_DeviceDrivers.h"

#define VBE_DISPI_INDEX_ID			0x0
#define VBE_DISPI_INDEX_XRES		0x1
#define VBE_DISPI_INDEX_YRES		0x2
#define VBE_DISPI_INDEX_BPP			0x3
#define VBE_DISPI_INDEX_ENABLE		0x4
#define VBE_DISPI_INDEX_BANK		0x5
#define VBE_DISPI_INDEX_VIRT_WIDTH	0x6
#define VBE_DISPI_INDEX_VIRT_HEIGHT	0x7
#define VBE_DISPI_INDEX_X_OFFSET	0x8
#define VBE_DISPI_INDEX_Y_OFFSET	0x9

#define VBE_DISPI_DISABLED      0x00
#define VBE_DISPI_ENABLED		0x01
#define VBE_DISPI_LFB_ENABLED	0x40
#define VBE_DISPI_NOCLEARMEM	0x80

bool VerifyBGAVersion()
{
	asmOutWord(0x01CE, VBE_DISPI_INDEX_ID);
	return (asmInWord(0x01CF) == (short)0xB0C5) ? true : false;
}

void InitializeBGA_LFB(int X_Resolution, int Y_Resolution, BPP BytesPerPixel)
{
	//Write error management code/ command successful verification code for this function
	asmOutWord(0x01CE, VBE_DISPI_INDEX_ENABLE);
	asmOutWord(0x01CF, VBE_DISPI_DISABLED);

	asmOutWord(0x01CE, VBE_DISPI_INDEX_XRES);
	asmOutWord(0x01CF, X_Resolution);

	asmOutWord(0x01CE, VBE_DISPI_INDEX_YRES);
	asmOutWord(0x01CF, Y_Resolution);

	asmOutWord(0x01CE, VBE_DISPI_INDEX_BPP);
	asmOutWord(0x01CF, BytesPerPixel);

	asmOutWord(0x01CE, VBE_DISPI_INDEX_ENABLE);
	asmOutWord(0x01CF, VBE_DISPI_ENABLED | VBE_DISPI_LFB_ENABLED | VBE_DISPI_NOCLEARMEM);
}

//TODO: The address of the frame buffer is not fixed, and must be read from the first PCI base address register

void ClearVBEScreen(VBEColor ClearToColor)
{
	int* video_memory = (int*)VBE_DISPI_LFB_PHYSICAL_ADDRESS;
	for (int i = 0; i < VBE_HEIGHT; i++)
	{
		for (int j = 0; j < VBE_WIDTH; j++)
		{
			*video_memory = VBEColorToInt(ClearToColor);
			video_memory++;
		}
	}
}