#include"..\..\include\GenLib.h"
#include"..\..\include\HAL_DeviceDrivers.h"

void InitKeyboardBuffer()
{
	PutInMem((int*)0x1000000, intT, (GenericValue) { .intVal = 0 }); //At the 16MB mark, we make POINTER To READ HEAD
	PutInMem((int*)0x1000004, intT, (GenericValue) { .intVal = 0 }); //At the 16MB + 4bytes mark, we make POINTER To READ HEAD
}

void AddByteToBuffer()
{
	int* insertPtr = (int*)0x1000004;
	*((int*)(0x1000008 + *insertPtr)) = asmInByte(KBRDEnc_InputBuffer);
	*insertPtr = (int)(*insertPtr + 1);
	if (*insertPtr == 0x1100000) *insertPtr = 0;
}

__attribute__((interrupt)) void AddByteToBufferIR(InterruptStackframe* ishandle)
{
	//__asm__ __volatile__("cli\n\t");
	int* insertPtr = (int*)0x1000004;
	*((int*)(0x1000008 + *insertPtr)) = asmInByte(KBRDEnc_InputBuffer);
	*insertPtr = (int)(*insertPtr + 1);
	if (*insertPtr == 0x1100000) *insertPtr = 0;
	SendEOI();
	//__asm__ __volatile__("sti\n\t");
}

byte GetByteFromBuffer()
{
	int* headPtr = (int*)0x1000000;
	int* insertPtr = (int*)0x1000004;
	if (*headPtr == *insertPtr) return (byte)0;
	byte read = *((int*)(0x1000008 + *headPtr));
	*headPtr = (int)(*headPtr + 1);
	if (*headPtr == 0x1100000) *headPtr = 0;
	return read;
}