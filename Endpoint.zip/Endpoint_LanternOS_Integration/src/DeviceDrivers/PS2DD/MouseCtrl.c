#include"..\..\include\GenLib.h"
#include"..\..\include\HAL_DeviceDrivers.h"

void InitMouseCursor()
{
	PutInMem((int*)0x10000C, intT, (GenericValue) { .intVal = 2 }); //Cursor X value
	PutInMem((int*)0x100010, intT, (GenericValue) { .intVal = 2 }); //cursor Y value

	asmOutByte(0x64, 0xD4);
	asmOutByte(0x60, 0xF5);

	byte x = 0b01000111;	
	asmOutByte(0x64, 0x60);
	while ((asmInByte(0x64) & (byte)1) != 0) asmInByte(0x60);
	asmOutByte(0x60, x);

	while (asmInByte(0x64) & 2);
	asmOutByte(0x64, 0xD4);
	asmOutByte(0x60, 0xF4);
}

void GetMouseStatus()
{
	sizeof(int*);
}

__attribute__((interrupt)) void UpdateCursorDataIR(InterruptStackframe* ishandle)
{
	__asm__ __volatile__("cli\n\t");
	byte mouseData = asmInByte(KBRDEnc_InputBuffer);
	if (mouseData & 0b00001000)
	{
		byte delX = 10;
		byte delY = 10;
		delX += asmInByte(KBRDEnc_InputBuffer);
		delY += asmInByte(KBRDEnc_InputBuffer);

		int* vidMem = (int*)VBE_DISPI_LFB_PHYSICAL_ADDRESS;
		*vidMem = *vidMem ? 0x0 : 0xFFFFFF;

		for (int i = 0; i < 5; i++)
		{
			for (int j = 0; j < 5; j++)
			{
				*(vidMem + (((int)delY + i) * 1280) + ((int)delX + j)) = 0;
			}
		}
	}
	SendSlaveEOI();
	__asm__ __volatile__("sti\n\t");
}

void UpdateCursorData()
{	
	/*Cursor cursor = (Cursor){
	GetFromMem((int*)0x10000C, intT).intVal,
	GetFromMem((int*)0x100010, intT).intVal
	};
	*/
	byte mouseData =  asmInByte(KBRDEnc_InputBuffer);
	if (!(mouseData & (byte)0b11000000)) return;
	byte delX = asmInByte(KBRDEnc_InputBuffer);
	byte delY = asmInByte(KBRDEnc_InputBuffer);
	//int mouseWheel = asmInByte(KBRDEnc_InputBuffer);
	
	/*char cursorBMP[360] = "110000000000000111000000000000111000000000000111100000000000111110000000000111111000000000111111000000000"
		"111111100000000111111110000000111111111000000111111111000000111111111100000111111111110000111111111111000111111111111100"
		"111111111111110111111111111111111111111111111111111100000000111110000000000111100000000000111000000000000110000000000000"
		"100000000000000"; //15x24 px
	*/
	int* cursorBGPtr = (int*)0x100014;
	int* vidMem = (int*)VBE_DISPI_LFB_PHYSICAL_ADDRESS;
	/*
	for (int i = 0; i < 24; i++)
	{
		for (int j = 0; j < 15; j++)
		{
			*(vidMem + ((cursor.Y + i) * 1280) + (cursor.X + j)) = *(cursorBGPtr + (i * 15) + j);
		}
	}

	cursor.X = cursor.X + delX;
	cursor.Y = cursor.Y + delY;
	if (cursor.X < 0) cursor.X = 0;
	if (cursor.Y < 0) cursor.Y = 0;
	if (cursor.X > 1264) cursor.X = 1264;
	if (cursor.X > 695) cursor.X = 695;

	for (int i = 0; i < 24; i++)
	{
		for (int j = 0; j < 15; j++)
		{
			//*(cursorBGPtr + (i * 15) + j) = *(vidMem + ((cursor.Y + i) * 1280) + (cursor.X + j));
			*(vidMem + ((cursor.Y + i) * 1280) + (cursor.X + j)) = cursorBMP[(i * 15) + j]?0xFFFFFF:0x0; // ? cursorBMP[(i * 15) + j] : *(cursorBGPtr + (i * 15) + j);
		}
	}*/




	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			//*(cursorBGPtr + (i * 15) + j) = *(vidMem + ((cursor.Y + i) * 1280) + (cursor.X + j));
			*(vidMem + (((int)delY + i) * 1280) + ((int)delX + j)) = 0xFF00; // ? cursorBMP[(i * 15) + j] : *(cursorBGPtr + (i * 15) + j);
		}
	}
}