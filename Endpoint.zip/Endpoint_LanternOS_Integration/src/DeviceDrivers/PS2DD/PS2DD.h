// PS2 KEYBOARD

typedef enum KBRDRead
{
	KBRDEnc_InputBuffer = 0x60,
	KBRDCtrl_Status = 0x64
} KBRDRead;

typedef enum KBRDWrite
{
	KBRDEnc_SendCommand = 0x60,
	KBRDCtrl_SendCommand = 0x64
} KBRDWrite;

typedef enum KBRDCtrlStatusGet
{
	KBRDCtrlStatusGet_ReadInputBUF =0b00000001, //Get what was typed to keyboard
	KBRDCtrlStatusGet_WriteOutputBUF = 0b00000010, //give command (e.g. to set LEDs) / data to keyboard (e.g. which LED to light)
	KBRDCtrlStatusGet_SYSTEM = 0b00000100,
	KBRDCtrlStatusGet_OBUFContent = 0b00001000, //last write was command(1)(0x64) or data(0)(0x60)
	KBRDCtrlStatusGet_LOCKED = 0b00010000,
	KBRDCtrlStatusGet_PS2MOUSE =0b00100000, // Keyboard data (0) , Mouse Data (1)
	KBRDCtrlStatusGet_TIMEOUT =0b01000000,
	KBRDCtrlStatusGet_ParityError = 0b10000000
} KBRDCtrlStatusGet;

typedef enum KBRDEncCommand
{
	KBRDEncCommand_SetLEDs = 0xED,
	KBRDEncCommand_EnableKBRD = 0xF4,
	KBRDEncCommand_ResendLastResult = 0xFE,
	KBRDEncCommand_Echo = 0xEE, //returns 0xEE to 0x60 as diagnostic test
	KBRDEncCommand_AutoRepeat = 0xF3 //Set autorepeat delay and repeat rate
} KBRDEncCommand;

typedef enum KBRDCtrlCommand
{
	KBRDCtrlCommand_ReadCmndbyte	= 0x20,
	KBRDCtrlCommand_WriteCmndByte	= 0x60,
	KBRDCtrlCommand_SelfTest		= 0xAA,
	KBRDCtrlCommand_InterfaceTest	= 0xAB,
	KBRDCtrlCommand_DisableKeyboard	= 0xAD,
	KBRDCtrlCommand_EnableKeyboard	= 0xAE,
	KBRDCtrlCommand_ReadInputPort	= 0xC0,
	KBRDCtrlCommand_ReadOutputPort	= 0xD0,
	KBRDCtrlCommand_WriteOutputPort	= 0xD1,
	KBRDCtrlCommand_SystemReset		= 0xFE,
	KBRDCtrlCommand_DisableMousePort= 0xA7,
	KBRDCtrlCommand_EnableMousePort	= 0xA8,
	KBRDCtrlCommand_TestMousePort	= 0xA9,
	KBRDCtrlCommand_WriteToMouse	= 0xD4,
	// Non - standard commands: 
	KBRDCtrlCommand_WriteMouseOutputBuffer	= 0xD3,
	KBRDCtrlCommand_DisableA20				= 0xDD,
	KBRDCtrlCommand_EnableA20				= 0xDF
} KBRDCtrlCommand;

typedef enum KBRDLEDS
{
	num, caps, scrl
} KBRDLEDS;

void SendCommandToKBRDEncoder(KBRDEncCommand comnd);
void SendDataToKBRDEncoder(byte data);
void SendCommandToKBRDController(KBRDCtrlCommand comnd);
void SendDataToKBRDController(byte data);
bool GetKBRDStatusOf(KBRDCtrlStatusGet what);
void SetKBRDLEDs(KBRDLEDS led, bool value);
void SetAutoRepeat(byte RepeatRate, byte AutoRepeatDelay);

void InitKeyboardBuffer();
void AddByteToBuffer();
__attribute__((interrupt)) void AddByteToBufferIR(InterruptStackframe* ishandle);
byte GetByteFromBuffer();

// PS2 MOUSE

typedef struct Cursor
{
	int X;
	int Y;
} Cursor;

void InitMouseCursor();
void UpdateCursorData();
__attribute__((interrupt)) void UpdateCursorDataIR(InterruptStackframe* ishandle);