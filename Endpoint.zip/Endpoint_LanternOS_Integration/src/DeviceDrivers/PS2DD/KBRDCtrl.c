#include"..\..\include\GenLib.h"
#include"..\..\include\HAL_DeviceDrivers.h"

void SendCommandToKBRDEncoder(KBRDEncCommand comnd)
{
	asmOutByte(KBRDEnc_SendCommand, (byte)comnd);
}

void SendDataToKBRDEncoder(byte data)
{
	asmOutByte(KBRDEnc_SendCommand, data);
}

void SendCommandToKBRDController(KBRDCtrlCommand comnd)
{
	asmOutByte(KBRDCtrl_SendCommand, (byte)comnd);
}

void SendDataToKBRDController(byte data)
{
	asmOutByte(KBRDEnc_SendCommand, data);
}

bool GetKBRDStatusOf(KBRDCtrlStatusGet what)
{
	return (asmInByte(KBRDCtrl_Status) & what) ? true : false;
}

void SetKBRDLEDs(KBRDLEDS led, bool value)
{
	//TODO: nit and store the LED values; temporarily this code turns numlock on Bit 0: Scroll Bit 1: Num Bit 2 : Caps 
	SendCommandToKBRDEncoder(KBRDEncCommand_SetLEDs);
	byte data = 0b00000010;
	/*switch (led)
	{
	case num:

	}*/
	SendDataToKBRDEncoder(data);
}

void SetAutoRepeat(byte RepeatRate, byte AutoRepeatDelay)
{
	SendCommandToKBRDEncoder(KBRDEncCommand_AutoRepeat);
	SendDataToKBRDEncoder((byte)(0b01111111 & ((AutoRepeatDelay & 0b11) << 5) & (RepeatRate & 0b11111)));
}