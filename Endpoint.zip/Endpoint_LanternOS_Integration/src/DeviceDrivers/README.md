This Folder serves as the Hardware Abstraction Layer (HAL) and is 
expendable when it comes to different architectures. The files
like, VideoDD.h may remain , since they are like standard
specification files, but their implementation, like
CGATextMode.c may be replaced with other code