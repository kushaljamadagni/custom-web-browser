#include"..\..\include\GenLib.h"
#include"..\..\include\HAL_DeviceDrivers.h"

void InitializeControlWord1(bool IsReceiveICW4, bool IsSinglePIC, bool IsLevelTriggeredMode, bool IsPICToBeInit)
{
	byte icw1 = (byte)(((byte)(0) << 5) | ((byte)(IsPICToBeInit) << 4) | ((byte)(IsLevelTriggeredMode) << 3)
		| ((byte)(0) << 2) | ((byte)(IsSinglePIC) << 1) | (byte)(IsReceiveICW4));
	asmOutByte(PrimPICCmdNStatusPort, icw1);
	asmOutByte(SecPICCmdNStatusPort, icw1);
}

void InitializeControlWord2(byte PIC1_IDTNumber, byte PIC2_IDTNumber)
{
	asmOutByte(PrimPICIMRNDataPort, PIC1_IDTNumber);
	asmOutByte(SecPICIMRNDataPort, PIC2_IDTNumber);
}

void InitializeControlWord3(byte PICTOSlaveIRQNumber) //we have IRQ: 0 -> 7
{
	asmOutByte(PrimPICIMRNDataPort, (((byte)1) << (byte)PICTOSlaveIRQNumber));
	asmOutByte(SecPICIMRNDataPort, PICTOSlaveIRQNumber);
}

void InitializeControlWord4(bool Is80x86Mode, bool IsAutomaticEOI, bool IsBUFMaster, bool IsBUFMode, bool SFNM) //SFNM -> many cascading controllers
{
	byte icw4 = (byte)(((byte)(0) << 5) | ((byte)(SFNM) << 4) | ((byte)(IsBUFMode) << 3)
		| ((byte)(IsBUFMaster) << 2) | ((byte)(IsAutomaticEOI) << 1) | (byte)(Is80x86Mode));
	asmOutByte(PrimPICIMRNDataPort, icw4);
	asmOutByte(SecPICIMRNDataPort, icw4);
}

byte ReadIMR()
{
	return asmInByte(PrimPICCmdNStatusPort);
}

// OCW2 commands to control the PIC : 

void SendEOI()
{
	asmOutByte(PrimPICCmdNStatusPort, 0x20);	//set bit 4 of OCW 2
}

void SendSlaveEOI()
{
	asmOutByte(PrimPICCmdNStatusPort, 0x20);
	asmOutByte(SecPICCmdNStatusPort, 0x20);
}