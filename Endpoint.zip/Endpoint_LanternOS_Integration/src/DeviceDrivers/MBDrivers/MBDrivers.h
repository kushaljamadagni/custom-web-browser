#include<stdbool.h>

typedef enum PICSoftwarePorts
{
	PrimPICCmdNStatusPort	= 0x20,
	PrimPICIMRNDataPort		= 0x21,
	SecPICCmdNStatusPort	= 0xA0,
	SecPICIMRNDataPort		= 0xA1
} PICSoftwarePorts;

typedef enum PITCounterPort
{
	PITCounter0RegPort	= 0x40,
	PITCounter1RegPort	= 0x41,
	PITCounter2RegPort	= 0x42,
	PITCommandPort		= 0x43
} PITCounterPort;

typedef enum PITOperatingModes
{
	PITMode0_Interrupt_TerminalCount	= 0b000,
	PITMode1_Programmable_one_shot		= 0b001,
	PITMode2_RateGenerator				= 0b010,
	PITMode3_SquareWaveGenerator		= 0b011,
	PITMode4_SoftwareTriggeredStrobe	= 0b100,
	PITMode5_HardwareTriggeredStrobe	= 0b101
} PITOperatingModes;

typedef enum PITCounter
{
	PIT_Counter0 = 0b00,
	PIT_Counter1 = 0b01,
	PIT_Counter2 = 0b10,
} PITCounter;

typedef enum PITCounterRegData
{
	CounterLatched	= 0b00,
	ReadLSBonly		= 0b01,
	ReadMSBonly		= 0b10,
	ReadLSBthenMSB	= 0b11,
} PITCounterRegData;

void InitializePIT(short frequencyHZ, PITOperatingModes OPMode, PITCounter counterNumber, PITCounterRegData counterRegData, bool isBCD);
__attribute__((interrupt)) void TimeManager(InterruptStackframe* ishandle);

void InitializeControlWord1(bool IsReceiveICW4, bool IsSinglePIC, bool IsLevelTriggeredMode, bool IsPICToBeInit);
void InitializeControlWord2(byte PIC1_IDTNumber, byte PIC2_IDTNumber);
void InitializeControlWord3(byte PICTOSlaveIRQNumber);
void InitializeControlWord4(bool Is80x86Mode, bool IsAutomaticEOI, bool IsBUFMaster, bool IsBUFMode, bool SFNM);
byte ReadIMR();

// OCW2 commands to control the PIC : 

void SendEOI();
void SendSlaveEOI();