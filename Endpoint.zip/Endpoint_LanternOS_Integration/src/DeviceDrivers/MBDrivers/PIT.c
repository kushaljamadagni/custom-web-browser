#include"..\..\include\GenLib.h"
#include"..\..\include\HAL_DeviceDrivers.h"

void InitializePIT(short frequencyHZ, PITOperatingModes OPMode, PITCounter counterNumber, PITCounterRegData counterRegData, bool isBCD)
{
	short count = (short)((short)1193180 / frequencyHZ);
	byte comd = (byte)(((byte)(counterNumber) << 6)	| ((byte)(counterRegData) << 4) | ((byte)(OPMode) << 1) | (byte)(isBCD));
	asmOutByte((short)PITCommandPort, comd);
	asmOutByte((short)PITCounter0RegPort, (byte)(count));
	asmOutByte((short)PITCounter0RegPort, (byte)((byte)(count) >> 8));
}

void SecondsInc()
{
	int* time = (int*)0x100018;
	*time = *time + 1;
}

__attribute__((interrupt)) void TimeManager(InterruptStackframe* ishandle)
{
	//__asm__ __volatile__("cli\n\t");
	int* time = (int*)0x100014;
	*time = *time + 1;
	if (*time == 100)
	{
		SecondsInc();
		*time = 0;
	}
	SendEOI();
	//__asm__ __volatile__("cli\n\t");
}