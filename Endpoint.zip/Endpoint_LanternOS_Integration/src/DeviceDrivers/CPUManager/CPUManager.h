#define IDT_BaseAddress	0x200000

typedef enum GateDescriptorPriviligeLevel
{
	RING_0 = 0b00,
	RING_1 = 0b01, 
	RING_2 = 0b10,
	RING_3 = 0b11
} GateDescriptorPriviligeLevel;

typedef enum IDType
{
	 IDBITS_32 = 0b01110,
	 IDBITS_16 = 0b00110	
} IDType;

typedef enum TGType
{
	TGBITS_32 = 0b01111,
	TGBITS_16 = 0b00111
} TGType;

typedef struct Interrupt
{
	GateDescriptorPriviligeLevel IDPL; //00:Ring0	01:Ring1	10:Ring2	11:Ring3
	IDType id_16or32;
} Interrupt;

typedef struct TrapGate
{
	GateDescriptorPriviligeLevel TGPL; //00:Ring0	01:Ring1	10:Ring2	11:Ring3
	TGType tg_16or32;
} TrapGate;

typedef struct InterruptStackframe
{
	int errCode;
	int eip;
	int ecs;
	int flags;
} InterruptStackframe;

typedef enum PICIRNumber
{
	Timer			= 0,
	Keyboard		= 1,
	SlaveController	= 2,
	SerialPort2		= 3,
	SerialPort1		= 4,
	DisketteDrive	= 6,
	ParallelPort1	= 7,
	CMOSRealTimeClock	= 8, 
	CGAVerticalRetrace	= 9, 
	Mouse	= 12,
	FPU		= 13,
	HardDiskController = 14
} PICIRNumber;

void InitializeIDT();
void LoadIDTR();
void EnableInterrupts();
void DisableInterrupts();
void AddInterrupt(byte IntNumber, int* Function_Addr, Interrupt I_Props);
void AddTrapGate(byte IntNumber, int* Function_Addr, TrapGate TG_Props);
void AddHardwareInterrupt(PICIRNumber picIRNumber, int* Function_Addr, Interrupt I_Props);