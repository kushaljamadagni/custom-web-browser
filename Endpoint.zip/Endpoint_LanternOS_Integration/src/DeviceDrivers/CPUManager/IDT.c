#include"..\..\include\GenLib.h"
#include"..\..\include\HAL_DeviceDrivers.h"

void InitializeIDT()
{
	
}

void LoadIDTR()
{
	__asm__ __volatile__("lidt	LoadIDT	\n\t");
}

void EnableInterrupts()
{
	__asm__ __volatile__("sti	\n\t");
}

void DisableInterrupts()
{
	__asm__ __volatile__("cli	\n\t");
}

void AddInterrupt(byte IntNumber, int* Function_Addr, Interrupt I_Props)
{
	short Function_low_addr_offset = (short)Function_Addr;
	short Function_high_addr_offset = (short)(((int)Function_Addr) >> 16);
	short* IDTaddr = (byte*)IDT_BaseAddress;
	IDTaddr += ((short)IntNumber * (short)4);
	*IDTaddr = Function_low_addr_offset;
	IDTaddr++;
	*IDTaddr = (short)0x08;
	IDTaddr++;

	byte* IDTaddrb = (byte*)(IDTaddr);
	*IDTaddrb = (byte)(0x0);
	IDTaddrb++;
	*IDTaddrb = (byte)(((byte)0x1 << 7) | ((byte)I_Props.IDPL << 5) | (byte)I_Props.id_16or32);

	IDTaddr++;
	*IDTaddr = Function_high_addr_offset;
}

void AddHardwareInterrupt(PICIRNumber picIRNumber, int* Function_Addr, Interrupt I_Props)
{
	short Function_low_addr_offset = (short)Function_Addr;
	short Function_high_addr_offset = (short)(((int)Function_Addr) >> 16);
	short* IDTaddr = (byte*)IDT_BaseAddress;
	IDTaddr += (short)((32 + picIRNumber) * (short)4);
	*IDTaddr = Function_low_addr_offset;
	IDTaddr++;
	*IDTaddr = (short)0x08;
	IDTaddr++;

	byte* IDTaddrb = (byte*)(IDTaddr);
	*IDTaddrb = (byte)(0x0);
	IDTaddrb++;
	*IDTaddrb = (byte)(((byte)0x1 << 7) | ((byte)I_Props.IDPL << 5) | (byte)I_Props.id_16or32);

	IDTaddr++;
	*IDTaddr = Function_high_addr_offset;
}

void AddTrapGate(byte IntNumber, int* Function_Addr, TrapGate TG_Props)
{
	short Function_low_addr_offset = (short)Function_Addr;
	short Function_high_addr_offset = (short)(((int)Function_Addr) >> 16);
	short* IDTaddr = (byte*)IDT_BaseAddress;
	IDTaddr += ((short)IntNumber * (short)4);
	*IDTaddr = Function_low_addr_offset;
	IDTaddr++;
	*IDTaddr = (short)0x08;
	IDTaddr++;

	byte* IDTaddrb = (byte*)(IDTaddr);
	*IDTaddrb = (byte)(0x0);
	IDTaddrb++;
	*IDTaddrb = (byte)(((byte)0x1 << 7) | ((byte)TG_Props.TGPL << 5) | (byte)TG_Props.tg_16or32);

	IDTaddr++;
	*IDTaddr = Function_high_addr_offset;
}