#include"..\include\HAL_DeviceDrivers.h"
#include"..\include\KernelSubModules.h"

void PreKernelMain(void)
{
	InitializeCGATextVideoDriver();
	char str[] = "LanternOS Pre-kernel VGA Mode";
	PrintToTerminalAt(str, VGA_WHITE, VGA_BLUE, (byte)25, (byte)13);
	char str2[] = "LanternOS, Copyright 2020";
	PrintToTerminalAtCursor(str2, VGA_WHITE, VGA_BLUE);
	char cont[] = "Press Any Key to Continue ...";
	PrintToTerminalAt(cont, VGA_LIGHT_RED, VGA_BLUE, (byte)25, (byte)24);
	PressAnyKeyToContinue();
	PressAnyKeyToContinue();
	InitializeBGAModeVideoDriver();
	InitCGUI();
	InitKeyboardBuffer();
	while ((asmInByte(0x64) & (byte)1) != 0) asmInByte(0x60);
	while ((asmInByte(0x64) & (byte)1) != 0) asmInByte(0x60);
	InitMouseCursor();
	InitInterrupts();
	InitPIC();
	InitPIT();
	while ((asmInByte(0x64) & (byte)1) != 0) asmInByte(0x60);
	while ((asmInByte(0x64) & (byte)1) != 0) asmInByte(0x60);
	EnableInterrupts();

	TextBlock TB;
	char ques[10] = "CHOOSE";
	char option1[20] = "F1    COMMAND LINE";
	char option2[21] = "F2    TORCH EDITOR 3";
	char option3[20] = "F3    RETURN";
	char logo[20] = "LANTERN OS";
	TB.wrapWidth = 50;
	while (1)
	{
		ResetNumberOfCharsDrawnLastTime();
		ClearVBEScreen((VBEColor) { .Alpha = 0, .Red = 243, .Green = 73, .Blue = 0 });

		TB.textColor = (VBEColor){ .Alpha = 0, .Red = 66, .Green = 9, .Blue = 5 };
		TB.pos = (PixelPosition){ .X = 550, .Y = 690 };
		StrCpy(TB.text, logo);
		DrawText(&TB, (VBEColor) { .Alpha = 0, .Red = 243, .Green = 73, .Blue = 0 });

		TB.textColor = (VBEColor){ .Alpha = 0, .Red = 0xFF, .Green = 0xFF, .Blue = 0xFF };
		TB.pos = (PixelPosition){ .X = 250, .Y = 50 };
		StrCpy(TB.text, ques);
		DrawText(&TB, (VBEColor) { .Alpha = 0, .Red = 243, .Green = 73, .Blue = 0 });

		TB.pos = (PixelPosition){ .X = 250, .Y = 80 };
		StrCpy(TB.text, option1);
		DrawText(&TB, (VBEColor) { .Alpha = 0, .Red = 243, .Green = 73, .Blue = 0 });

		TB.pos = (PixelPosition){ .X = 250, .Y = 110 };
		StrCpy(TB.text, option2);
		DrawText(&TB, (VBEColor) { .Alpha = 0, .Red = 243, .Green = 73, .Blue = 0 });

		TB.pos = (PixelPosition){ .X = 250, .Y = 140 };
		StrCpy(TB.text, option3);
		DrawText(&TB, (VBEColor) { .Alpha = 0, .Red = 243, .Green = 73, .Blue = 0 });

		byte ch = 0;
		while ((ch = GetByteFromBuffer()) == 0);
		if (ch == 0x3B)
		{
			ResetNumberOfCharsDrawnLastTime();
			CLI cli = CreateCLIWindow((Window) { 50, 50, (Margin) { 60, 40, 60, 40 } });
			StartCLIInput(cli);
		}
		else if (ch == 0x3C)
		{
			ResetNumberOfCharsDrawnLastTime();
			StartTorch();
		}
		else if (ch == 0x3D)
		{
			return;
		}
	}
}