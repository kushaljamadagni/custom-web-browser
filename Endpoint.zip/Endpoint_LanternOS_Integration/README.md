# Endpoint LanternOS Integration

This integration is a proof of concept that we can use Web Technologies to build the GUI of an OS. LanternOS is an OS project which was done in the spring of 2020 (Semester 2) in which we had a micro-kernel which could render GUI apps using pixel drawing, among a few other things that it could do.

Here, we intend to write functions within the LanternOS project which will help accelerate the development of GUI apps for LanternOS, using a version of the Endpoint Framework which integrates the backend (BE) and the frontend (FE) into one program, but still uses the concept of the FE function doing the rendering which the BE interprets the XML.

> Refer to the LanternOS repo for all the details regarding how the OS is run. Here, we shall only be describing the method by which we show the GUI.

## How to use it

There are a lot of build tools (software) that need to be installed and configured to run the OS. In order to simplify the process of running LanternOS, we will instead give you a pre-compiled binary that can use executed using only one software `BOCHS` on any device.

Steps to run the OS in BOCHS:

1. We will be using bochs to emulate in IA32 machine. install it from [here](https://sourceforge.net/projects/bochs/files/latest/download). we will run a file called `bochsrc.bxrc` which is a bochs machine config file.

   If you are using linux (with GUI, not wsl), then you can run `sudo apt install bochs` to install it.

2. The OS can be run using the `BOCHS` emulator by just having the latest version of `BOCHS` installed. Run `BochsEmulateRelease.bxrc` by double-clicking on it. The file is present in `~/Endpoint_LanternOS_Integration/artifacts` (`artfacts` folder).

## Credits

The LanternOS Project was done as a semester project done by T Tarun Aditya:

|NAME|SRN|EMAIL|
|----|----|----|
|T Tarun Aditya|PES1UG19CS535|tarun.aditya@hotmail.com|

The following people **barely** contributed to the project as part of the team. (to be fair, they **did try** to contribute, but couldn't make sense of everything leaving me to do the heavy lifting)

|NAME|SRN|EMAIL|
|----|----|----|
|Moyank Giri| PES1UG19CS280| moyank110@gmail.com|
Vaibhava Krishna D |PES1UG19ME217 |vkdevulapalli@hotmail.com|
Aravind Saligram |PES1UG19ME032| aravind.saligram@gmail.com|
