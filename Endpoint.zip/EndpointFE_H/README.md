# Endpoint FE (Hydrogen)

>NOTE: This frontend (FE) only supports DOMv1 BE-FE interface

This is the "Hydrogen" (first) model of the Endpoint Framework's frontend and is an implementation of the Endpoint FE framework which is capable of being created in various techonologies and programming languages.

We use the Python PL and `TKinter` library in python to create and use the frontend.

## Install, build and development

1. To use the FE, you need to install python (from their website) and then `TKinter` using the command `pip install tkinterx`.
2. You then need to run the frontend using command `python frontend.py` by opening the terminal in the folder where this README is located.

>NOTE: You might come across error saying a certain functional cannot run because something is not imported, etc. This might be because of the absence of the python packages/libraries like TKinter, requests, etc.

3. The default values in the UI which you see after running the python code match with the default values at the Backend, but beware to change the default values of the paths the nackend uses to access html and JS files as those have been written accoding to the developer's system and will not be the same on your system. Relative path support to backend will be arriving soon.

4. After launching the python UI, before connecting to the BE, make sure the BE is running. The BE (DOMv1) can be run using the instructions in the README of the BE.

## How does it work

It uses a special JSON based communication format over REST implemented by HTTP requests to the BE.

The obtained JSON is interpreted locally and rendered to GUI. There is no parsing other than just reading the json and rendering UI.

The JS functions are connected in such a way that the BE is called on instances like button click after which the UI is re-rendered to show the updated DOM.
