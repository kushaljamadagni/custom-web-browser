from tkinter import *
import requests
import urllib.request
import json
import os
from functools import partial

root = Tk()
root.geometry("350x200")

root.title("Endpoint Web Browser FE")

def update_webpage():
	html_json = requests.get(host_url + "/update")
	LoadWindow(html_json.text)

def LoadWebPage():
	global newWindow
	newWindow = Toplevel(root)
	newWindow.geometry("500x500")
	html_json = requests.get(host_url + "/loadhtml", params = {"host": html_host, "path":html_path})
	LoadWindow(html_json.text)
	load_js()

def load_js():
	js_result = requests.get(host_url + "/loadjs", params = {"host": js_host, "path":js_path})

def LoadWindow(html_json):
	global newWindow
	mt = 0
	ml = 0
	html_json = json.loads(html_json)
	if html_json != None:
		elements = html_json['elements']
		if elements != None:
			for i in elements:
				attr = i['attributes']
				if attr != None:
					try:
						mt += attr["Margin-Top"]
					except:
						mt += 0
					try:
						mb = attr["Margin-Bottom"]
					except:
						mb = 0
					try:
						ml = attr["Margin-Left"]
					except:
						ml = 0
					try:
						mr = attr["Margin-Right"]
					except:
						mr = 0
											
					try:
						width = attr["Width"]
					except:
						width = 0
					try:
						height = attr["Height"]
					except:
						height = 0
						
					newWindow.update()


					if mt != 0:
						if mb != 0:
							yp = mt + (newWindow.winfo_height() - mt - mb) / 2
						else:
							yp = mt + height/2
					else:
						if mb != 0:
							yp = newWindow.winfo_height() - mb + height / 2
						else:
							yp = mt + height/2

					if ml != 0:
						if mr != 0:
							xp = ml + (newWindow.winfo_width() - ml - mr) / 2
						else:
							xp = ml + width/2
					else:
						if mr != 0:
							xp = newWindow.winfo_width() - mr + width / 2
						else:
							xp = ml + width/2

					mt += height
					
					if (i['type'] == 'button'):
						b1 = Button(newWindow, text = i['PCDATA'],  command = partial(button_click_handler, attr  ["Click"]),   width = width, height = height)
						b1.place(x = xp, y = yp)
						
					if (i['type'] == 'h1'):
						h = Label(newWindow, text = i['PCDATA'], font = ('times', 16))
						h.place(x = xp, y = yp)

					if (i['type'] == 'textarea'):
						t = Text(newWindow,   width = width, height = height)
						t.place(x = xp, y = yp)


def button_click_handler(onclick):
	result = requests.get(host_url + "/click?func=" + onclick)
	print(result)
	update_webpage()

def go_to_webpage():
	global html_host
	html_host = html_host_tb.get()
	global html_path
	html_path = html_path_tb.get()
	global js_host
	js_host = js_host_tb.get()
	global js_path
	js_path = js_path_tb.get()
	global host_url
	host_url = host_tb.get()
	LoadWebPage()


def about():
	newWindow = Toplevel(root)
	newWindow.geometry('400x100')
	ab = "This is the Frontend (FE).\n It has been created by the Endpoint team.\nIt connects to the backend (BE) to receive data\n to render the GUI of the webpage.\n CAUTION: This works only with DOMv1 of the BE"
	l = Label(newWindow, text=ab, font="time 10")
	l.place(x = 10, y = 10)

def stop_server():
	requests.get(host_url + "/stop")

menubar = Menu(root)

editmenu = Menu(menubar, tearoff=0)
editmenu.add_separator()

helpmenu = Menu(menubar, tearoff=0)
helpmenu.add_command(label = "About", command = about)
menubar.add_cascade(label = "Help", menu = helpmenu)

root.config(menu = menubar)

tb1 = Label(root, text = "Host URL", font = "times 10")
tb1.place(x = 5, y = 10)

host_tb = Entry(root, width = 40)
host_tb.place(x = 90, y = 10)
host_tb.insert(0, 'http://localhost:8184')


tb2 = Label(root, text = "HTML URL", font = "times 10")
tb2.place(x = 5, y = 40)

html_host_tb = Entry(root, width = 20)
html_host_tb.place(x = 90, y = 40)
html_host_tb.insert(0, 'http://localhost:8184')

html_path_tb = Entry(root, width = 20)
html_path_tb.place(x = 220, y = 40)
html_path_tb.insert(0, '/dummies/html1')


tb3 = Label(root, text = "JS URL", font = "times 10")
tb3.place(x = 5, y = 70)

js_host_tb = Entry(root, width = 20)
js_host_tb.place(x = 90, y = 70)
js_host_tb.insert(0, 'http://localhost:8184')

js_path_tb = Entry(root, width = 20)
js_path_tb.place(x = 220, y = 70)
js_path_tb.insert(0, '/dummies/js1')

loadWP = Button(root, text = "Load Web Page", command = go_to_webpage, width = 20, bg = 'grey')
loadWP.place(x = 30, y = 100)

stop_server = Button(root, text = "Stop Server", command = stop_server, width = 20, bg = 'grey')
stop_server.place(x = 30, y = 130)

Update_webpage = Button(root, text = "Update webpage", command = update_webpage, width = 20, bg = 'grey')
Update_webpage.place(x = 30, y = 160)

root.mainloop()
