# Endpoint

## Introduction

> This readme has to be changed if (most probably) this repo is gonna be put up on github, to include screenshots and all stuff that introduces a potential contributor to the codebase to get interested i.e. we give the person all details her/she would like to know to see if they are capable of contributing and if they are interested or not. i.e. stuff like, build tools, features, pre-requites, issues, code of conduct, wiki, how to use it, packages, license , contributions,  etc. refer prev. projects.

## Specifics of this project

We have two parts to Endpoint (at the time of writing), the backend (EndpointBE) and the frontend (EndpointFE).

We use a version system based on elements in the periodic table. The version named given are not progressive, but are instead used to represent different types/frameworks being used in the project. This system only applies to the backend naming system. e.g. (EndpointBE_H, EndpointBE_He, EndpointBE_Al).

The front end will be named using the anniversary stones. (EndpointFE_Gold, EndpointFE_Garnet).

Read the README of each version inside it's folder for more info regarding that version.

## Documentation

The documentation for the code and framework of project related to any version is all available in azure repos in the "Endpoint Docs" repo.

The API documentation for each version is available in the respective version folder.

## Getting Started

Basic Installation Instructions:

- Clone repo and develop in the branch you are supposed to develop in.

## Build and Test

> add stuff here

## Contribute

> add stuff here

If you want to learn more about creating good readme files then refer the following [guidelines](https://docs.microsoft.com/en-us/azure/devops/repos/git/create-a-readme?view=azure-devops). You can also seek inspiration from the below readme files:

- [ASP.NET Core](https://github.com/aspnet/Home)
- [Visual Studio Code](https://github.com/Microsoft/vscode)
- [Chakra Core](https://github.com/Microsoft/ChakraCore)
