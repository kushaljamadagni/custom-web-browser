var str = 'Hello, World!';
print("What's the matter\nnothing");
print({ hell: 26, what: "this", obj: { sems1 : "pass", sems2 : "pass" }});
str = 'NICE road';
print(".\n");
