#include <iostream>
#include <fstream>
#include "jerryscript.h"
#include "jerryscript-ext/handler.h"

using namespace std;

//API usage examples: https://github.com/jerryscript-project/jerryscript/blob/master/docs/03.API-EXAMPLE.md

//API references: https://github.com/jerryscript-project/jerryscript/blob/master/docs/02.API-REFERENCE.md

void print_JS_object(const jerry_value_t object)
{
	jerry_value_t keys_array = jerry_get_object_keys(object);
	uint32_t len = jerry_get_array_length(keys_array);
	cout << "\n{ ";

	for (int i = 0; i < len; i++)
	{
		jerry_value_t key = jerry_get_property_by_index(keys_array, i);
		//jerry_type_t x = jerry_value_get_type(keys_array);

		jerry_char_t buffer[256];
		jerry_value_t key_string = jerry_value_to_string(key);
		jerry_size_t copied_bytes = jerry_string_to_utf8_char_buffer(key_string, buffer, sizeof(buffer) - 1);
		buffer[copied_bytes] = '\0';
		printf("%s: ", (const char*)buffer);


		jerry_value_t prop_value = jerry_get_property(object, key);
		if (jerry_value_is_number(prop_value))
		{
			double num = 0;
			num = jerry_get_number_value(prop_value);
			printf("%f ", num);
		}
		else if (jerry_value_is_string(prop_value))
		{
			jerry_char_t val[256];

			jerry_size_t copied_bytes = jerry_string_to_utf8_char_buffer(prop_value, val, sizeof(buffer) - 1);
			val[copied_bytes] = '\0';
			printf("%s ", val);
		}
		else if (jerry_value_is_object(prop_value))
		{
			print_JS_object(prop_value);
		}

		if (i + 1 != len) printf(", ");

		jerry_release_value(key);
		jerry_release_value(key_string);
		jerry_release_value(prop_value);
	}

	cout << "}\n";
	jerry_release_value(keys_array);
}

static jerry_value_t print_handler(
	const jerry_value_t function_object,
	const jerry_value_t function_this,
	const jerry_value_t arguments[],
	const jerry_length_t arguments_count)
{
	/* There should be at least one argument */
	if (arguments_count > 0)
	{
		//if (!strcmp("[object Object]", buffer2))
		if (jerry_value_is_string(arguments[0]))
		{
			/* Convert the first argument to a string (JS "toString" operation) */
			jerry_value_t string_value = jerry_value_to_string(arguments[0]);

			/* A naive allocation of buffer for the string */
			jerry_char_t buffer[256];
			//char buffer2[256];

			/* Copy the whole string to the buffer, without a null termination character,
			 * Please note that if the string does not fit into the buffer nothing will be copied.
			 * More details on the API reference page
			 */

			jerry_size_t copied_bytes = jerry_string_to_utf8_char_buffer(string_value, buffer, sizeof(buffer) - 1);
			buffer[copied_bytes] = '\0';

			printf("%s\n", (const char*)buffer);

			/* Release the "toString" result */
			jerry_release_value(string_value);
		}
		else if (jerry_value_is_object(arguments[0]))
		{
			print_JS_object(arguments[0]);
		}
	}
	else
	{
		cout << endl;
	}

	/* Return an "undefined" value to the JavaScript engine */
	return jerry_create_undefined();
}

int main(int argc, char** args)
{
	//CUSTOM VARIABLES:
	string path = "N:\\UNIVERSITY\\SEM 3 - Special Topic Mini Project\\Endpoint_(Azure_DevOps_Enygmator)\\EndpointBE_H\\src\\JS_engine\\JerryScript\\test.js"; //place your own path here

	bool run_ok = false;

	const jerry_char_t script1[] = "print1(str);";
	int script_len1 = sizeof(script1) - 1;
	jerry_char_t* script;
	size_t script_len;

	ifstream fstr;
	fstr.open(path, ios::in);
	if (!fstr) {
		cout << "File not read!\n";
		const jerry_char_t script_t[] = "var str = 'there'; print('this');";
		script_len = sizeof(script_t) - 1;
		script = (jerry_char_t*)calloc(script_len, sizeof(jerry_char_t));
		for (int i = 0; i < script_len; i++)
		{
			script[i] = script_t[i];
		}
	}
	else {
		string content((istreambuf_iterator<char>(fstr)), (istreambuf_iterator<char>()));
		script_len = content.length();
		script = (jerry_char_t*)calloc(script_len, sizeof(jerry_char_t));

		cout << "code to run:\n\n";
		int i = 0;
		while (i < script_len)
		{
			script[i] = (jerry_char_t)content[i];
			cout << script[i];
			i++;
		}
		cout << "\n\nCode Execution:\n\n";
		fstr.close();
	}

	/* Initialize engine */
	jerry_init(JERRY_INIT_EMPTY);
	jerryx_handler_register_global((const jerry_char_t*)"print1", jerryx_handler_print);

	{
		/* Get the "global" object */
		jerry_value_t global_object = jerry_get_global_object();
		/* Create a "print" JS string */
		jerry_value_t property_name_print = jerry_create_string((const jerry_char_t*)"print");
		/* Create a function from a native C method (this function will be called from JS) */
		jerry_value_t property_value_func = jerry_create_external_function(print_handler);
		/* Add the "print" property with the function value to the "global" object */
		jerry_value_t set_result = jerry_set_property(global_object, property_name_print, property_value_func);
		
		/* Check if there was no error when adding the property (in this case it should never happen) */
		if (jerry_value_is_error(set_result)) {
			printf("Failed to add the 'print' property\n");
		}

		/* Release all jerry_value_t-s */
		jerry_release_value(set_result);
		jerry_release_value(property_value_func);
		jerry_release_value(property_name_print);
		jerry_release_value(global_object);
	}

	/* Setup Global scope code */
	jerry_value_t parsed_code = jerry_parse(NULL, 0, script, script_len, JERRY_PARSE_NO_OPTS);

	/* Check if there is any JS code parse error */
	if (!jerry_value_is_error(parsed_code))
	{
		/* Execute the parsed source code in the Global scope */
		jerry_value_t ret_value = jerry_run(parsed_code);

		/* Check the execution return value if there is any error */
		run_ok = !jerry_value_is_error(ret_value);

		/* Returned value must be freed */
		jerry_release_value(ret_value);
	}
	else
	{
		cout << "There was an error in parsing the JS" << endl;
	}

	/* Parsed source code must be freed */
	jerry_release_value(parsed_code);
	

	/* Setup Global scope code */
	 parsed_code = jerry_parse(NULL, 0, script1, script_len1, JERRY_PARSE_NO_OPTS);

	/* Check if there is any JS code parse error */
	if (!jerry_value_is_error(parsed_code))
	{
		/* Execute the parsed source code in the Global scope */
		jerry_value_t ret_value = jerry_run(parsed_code);

		/* Check the execution return value if there is any error */
		run_ok = !jerry_value_is_error(ret_value);

		/* Returned value must be freed */
		jerry_release_value(ret_value);
	}
	else
	{
		cout << "There was an error in parsing the JS" << endl;
	}

	/* Parsed source code must be freed */
	jerry_release_value(parsed_code);

	/* Cleanup engine */
	jerry_cleanup();

	return (run_ok ? 0 : 1);
}