#include<iostream>
#include<conio.h>

#include "CommonLib.hpp"

using namespace std;

int main()
{
	print_Lib_info();
	cout << "This is a test file to check the build systems or whatever you're trying to do";
	_getch();
	return 0;
}