#include<iostream>
#include<string.h>
#include<vector>
//#include<stdc++.h>
#include<regex>

using namespace std;

/*
void printmatch(std::string str, std::regex reg)
{
	std::sregex_iterator currentmatch(str.begin(), str.end(), reg);
	std::sregex_iterator lastmatch;
	while (currentmatch != lastmatch)
	{
		std::smatch match = *currentmatch;
		std::cout << match.str() << endl;
		currentmatch++;
	}
}

int main()
{
	std::string line = "<!Doctype html><html><body><h1>my first heading</h1><p>my para</p></body></html>";
	std::string str = "cat rat mat";
	//std::vector<string> tokens;
	//stringstream check1(line);
	//string intermediate;
	std::regex reg("<([a-z]+>)");
	std::regex reg1("<(/[a-z]+>)");
	std::cout << "start tags are" << "\n";
	printmatch(line, reg);
	std::cout << "end  tags are" << "\n";
	printmatch(line, reg1);
}*/

//Using lexertk

#include "Lexertk.hpp"

int main()
{
	std::string expression = "<html><head><title> first page</title><head><<p>jdjfjjdjddjk</p></html>";

	lexertk::generator generator;

	if (!generator.process(expression))
	{
		std::cout << "Failed to lex: " << expression << std::endl;
		return 1;
	}

	lexertk::helper::dump(generator);

	return 0;
}