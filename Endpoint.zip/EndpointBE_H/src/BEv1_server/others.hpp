//#pragma once

#include <iostream>
#include <fstream>
#include "nlohmann/json.hpp"
#include "pugixml.hpp"
#include "httplib/httplib.h"
#include "re2/re2.h";
#include "jerryscript.h"
#include "jerryscript-ext/handler.h"

using namespace nlohmann;
using namespace std;
using namespace pugi;
using namespace httplib;

void print_JS_object(const jerry_value_t object);
void all_elements_to_json(xml_node node);

void print_json_file(string path);
void traverse_all_elements(xml_node node);

static jerry_value_t print_handler(
	const jerry_value_t function_object,
	const jerry_value_t function_this,
	const jerry_value_t arguments[],
	const jerry_length_t arguments_count)
{
	/* There should be at least one argument */
	if (arguments_count > 0)
	{
		//if (!strcmp("[object Object]", buffer2))
		if (jerry_value_is_string(arguments[0]))
		{
			/* Convert the first argument to a string (JS "toString" operation) */
			jerry_value_t string_value = jerry_value_to_string(arguments[0]);

			/* A naive allocation of buffer for the string */
			jerry_char_t buffer[256];
			//char buffer2[256];

			/* Copy the whole string to the buffer, without a null termination character,
			 * Please note that if the string does not fit into the buffer nothing will be copied.
			 * More details on the API reference page
			 */

			jerry_size_t copied_bytes = jerry_string_to_utf8_char_buffer(string_value, buffer, sizeof(buffer) - 1);
			buffer[copied_bytes] = '\0';

			printf("%s\n", (const char*)buffer);

			/* Release the "toString" result */
			jerry_release_value(string_value);
		}
		else if (jerry_value_is_object(arguments[0]))
		{
			print_JS_object(arguments[0]);
		}
	}
	else
	{
		cout << endl;
	}

	/* Return an "undefined" value to the JavaScript engine */
	return jerry_create_undefined();
}

