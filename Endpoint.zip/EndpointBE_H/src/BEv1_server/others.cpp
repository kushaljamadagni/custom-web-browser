#include "others.hpp"

extern int level;
extern int guid;

extern json dom_json;

extern bool;
extern bool;
extern const bool;
extern jerry_value_t parsed_code;
extern Server svr;

extern xml_document dom;

void print_JS_object(const jerry_value_t object)
{
	jerry_value_t keys_array = jerry_get_object_keys(object);
	uint32_t len = jerry_get_array_length(keys_array);
	cout << "\n{ ";

	for (int i = 0; i < len; i++)
	{
		jerry_value_t key = jerry_get_property_by_index(keys_array, i);
		//jerry_type_t x = jerry_value_get_type(keys_array);

		jerry_char_t buffer[256];
		jerry_value_t key_string = jerry_value_to_string(key);
		jerry_size_t copied_bytes = jerry_string_to_utf8_char_buffer(key_string, buffer, sizeof(buffer) - 1);
		buffer[copied_bytes] = '\0';
		printf("%s: ", (const char*)buffer);


		jerry_value_t prop_value = jerry_get_property(object, key);
		if (jerry_value_is_number(prop_value))
		{
			double num = 0;
			num = jerry_get_number_value(prop_value);
			printf("%f ", num);
		}
		else if (jerry_value_is_string(prop_value))
		{
			jerry_char_t val[256];

			jerry_size_t copied_bytes = jerry_string_to_utf8_char_buffer(prop_value, val, sizeof(buffer) - 1);
			val[copied_bytes] = '\0';
			printf("%s ", val);
		}
		else if (jerry_value_is_object(prop_value))
		{
			print_JS_object(prop_value);
		}

		if (i + 1 != len) printf(", ");

		jerry_release_value(key);
		jerry_release_value(key_string);
		jerry_release_value(prop_value);
	}

	cout << "}\n";
	jerry_release_value(keys_array);
}

void all_elements_to_json(xml_node node)
{
	for (xml_node child : node.children())
	{
		//for (int i = 0; i < level; i++) cout << "  ";
		if (strcmp(child.name(), ""))
		{
			//cout << child.name() << " : ";
			json t, a;
			t["type"] = child.name();
			t["guid"] = guid;
			for (xml_attribute attr : child.attributes())
			{
				//cout << "  " << attr.name() << "=\"" << attr.value() << "\"";
				if (!strcmp(attr.name(), "Click") || !strcmp(attr.name(), "click"))
				{
					string s = string(attr.value());
					string t = "";
					RE2::FullMatch(s, "(.+)[(][)]", &t);
					a["Click"] = t;
				}
				else if (!strcmp(attr.name(), "maxlength"))
				{
					a["MaxChar"] = attr.value();
				}
				else if (!strcmp(attr.name(), "style"))
				{
					int i = 0;
					string s = "";
					string style(attr.value());

					RE2::PartialMatch(style, "mar(\\w+)-left:(\\d+)px;", &s, &i);
					if (s == "gin") a["Margin-Left"] = i;
					s = "";
					RE2::PartialMatch(style, "mar(\\w+)-top:(\\d+)px;", &s, &i);
					if (s == "gin") a["Margin-Top"] = i;
					s = "";
					RE2::PartialMatch(style, "mar(\\w+)-right:(\\d+)px;", &s, &i);
					if (s == "gin") a["Margin-Right"] = i;
					s = "";
					RE2::PartialMatch(style, "mar(\\w+)-bottom:(\\d+)px;", &s, &i);
					if (s == "gin") a["Margin-Bottom"] = i;
					s = "";
					RE2::PartialMatch(style, "hei(\\w+)[\\s]*:[\\s]*(\\d+)px;", &s, &i);
					if (s == "ght") a["Height"] = i;
					s = "";
					RE2::PartialMatch(style, "wi(\\w+)[\\s]*:[\\s]*(\\d+)px;", &s, &i);
					if (s == "dth") a["Width"] = i;
					s = "";
				}
				/*else if (!strcmp(attr.name(), ""))
				{

				}*/
				else
				{
					a[attr.name()] = attr.value();
				}
			}
			//cout << endl;
			t["attributes"] = a;
			dom_json["elements"][guid] = t;
			level++;
			guid++;
			all_elements_to_json(child);
		}
		if (strcmp(child.child_value(), ""))
		{
			//printf("%s\n", child.child_value());
			dom_json["elements"][guid - 1]["PCDATA"] = child.child_value();
		}
	}
	level--;
}

void print_json_file(string path)
{
	ifstream fstr;
	fstr.open(path, ios::in);
	if (!fstr) {
		cout << "File not read!\n";
	}
	else {
		json j;
		fstr >> j;
		cout << j.dump(4) << endl;
		fstr.close();
	}
}

void traverse_all_elements(xml_node node)
{
	for (xml_node child : node.children())
	{
		for (int i = 0; i < level; i++) cout << "  ";
		if (strcmp(child.name(), ""))
		{
			cout << child.name() << " : ";
			for (xml_attribute attr : child.attributes()) cout << "  " << attr.name() << "=\"" << attr.value() << "\"";
			cout << endl;
			level++;
			traverse_all_elements(child);
		}
		if (strcmp(child.child_value(), ""))
		{
			printf("%s\n", child.child_value());
		}
	}
	level--;
}

