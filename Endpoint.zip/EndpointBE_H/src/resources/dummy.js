var x = 1;
var y = 2;

function add_button_to_dom() {
    var button_props = {
        "click": null,
        "style": "margin-top:40px; margin-left:5px; height: 1px; width: 40px; border-radius:3px;"
    };
    XMLDOM.addElement("button", button_props, "Nothing happens when you click me");
    //type = "button" , html_attributes = {...}, content (PCDATA) = "Click me"
}

var z = x + y;
print("It's just the beginning\nthe value of z is: ");
print1(z);
print("\n");
