#include <iostream>
#include <fstream>
#include "nlohmann/json.hpp"
#include "pugixml.hpp"
#include "css_parser.hpp"

using namespace nlohmann;
using namespace std;
using namespace pugi;

void print_json_file(string path)
{
	ifstream fstr;
	fstr.open(path, ios::in);
	if (!fstr) {
		cout << "File not read!\n";
	}
	else {
		json j;
		fstr >> j;
		cout << j.dump(4) << endl;
		fstr.close();
	}
}

int level = 0;

void traverse_all_elements(xml_node node)
{
	for (xml_node child : node.children())
	{
		for (int i = 0; i < level; i++) cout << "  ";
		if (strcmp(child.name(),""))
		{
			cout << child.name() << " : ";
			for (xml_attribute attr : child.attributes()) cout << "  " << attr.name() << "=\"" << attr.value() << "\"";
			cout << endl;
			level++;
			traverse_all_elements(child);
		}
		if (strcmp(child.child_value(), ""))
		{
			printf("%s\n", child.child_value());
		}
	}
	level--;
}

int main(int argc, char** args)
{
	//CUSTOM VARIABLES:
	string html_path = "N:\\UNIVERSITY\\SEM 3 - Special Topic Mini Project\\Endpoint_(Azure_DevOps_Enygmator)\\EndpointBE_H\\src\\resources\\dummy.html"; //place your own path here

	string css_path = "N:\\UNIVERSITY\\SEM 3 - Special Topic Mini Project\\Endpoint_(Azure_DevOps_Enygmator)\\EndpointBE_H\\src\\resources\\dummy.css"; //place your own path here
	
	//print_json_file(path);
	xml_document dom;
	xml_parse_result result = dom.load_file(html_path.c_str());
	if (result)
	{
		traverse_all_elements(dom);
	}
	
	string css = "";

	std::ifstream file;
	
	file.open(css_path);

	while (file.good()) {
		css += file.get();
	}

	// Parse it.
	CSSParser prs = CSSParser(css);

	while (!prs.AtEnd()) {
		CSSToken tok = prs.GetCSSToken();

		prs.Err.Print(); // HTML/CSS are very forgiving.

		if (tok.Selector.Type == SelectorType::Id)
			std::cout << "#";

		if (tok.Selector.Type == SelectorType::Class)
			std::cout << ".";

		std::cout << tok.Selector.Subject << ":\n";

		// Loop through rule styles like color and width(only supports text like red blue etc right now)
		for (std::pair<string, CSSStyle> pair : tok.Styles) {
			std::cout << pair.first << ": " << pair.second.Text << "\n";
		}

		std::cout << "\n";
	}

	getchar();
	return 0;
}