#include "others.hpp"

bool js_run_ok = false;
bool js_init = false;
const bool run_js = true;
jerry_value_t parsed_code;
Server svr;

xml_document dom;

namespace XMLDOM
{
	static jerry_value_t addElement(
		const jerry_value_t function_object,
		const jerry_value_t function_this,
		const jerry_value_t arguments[],
		const jerry_length_t arguments_count)
	{
		if (arguments_count == 3)
		{
			//if (!strcmp("[object Object]", buffer2))
			if (jerry_value_is_string(arguments[0]) && jerry_value_is_object(arguments[1]) && jerry_value_is_string(arguments[2]))
			{
				/* Convert the first argument to a string (JS "toString" operation) */
				jerry_value_t arg1 = jerry_value_to_string(arguments[0]);
				jerry_value_t arg3 = jerry_value_to_string(arguments[2]);
		
				/* A naive allocation of buffer for the string */
				jerry_char_t buffer1[256];
				char_t str1[256];
				jerry_char_t buffer2[256];
				char_t str2[256];

				jerry_size_t copied_bytes1 = jerry_string_to_utf8_char_buffer(arg1, buffer1, sizeof(buffer1) - 1);
				buffer1[copied_bytes1] = '\0';
				for (int i = 0; i < 256; i++) str1[i] = buffer1[i];

				jerry_size_t copied_bytes2 = jerry_string_to_utf8_char_buffer(arg3, buffer2, sizeof(buffer2) - 1);
				buffer2[copied_bytes2] = '\0';
				for (int i = 0; i < 256; i++) str2[i] = buffer2[i];

				xml_node button = dom.child("html").child("body").append_child(str1);
				if (button)
				{
					button.append_child(pugi::node_pcdata).set_value(str2);

					jerry_value_t keys_array = jerry_get_object_keys(arguments[1]);
					uint32_t len = jerry_get_array_length(keys_array);

					for (int i = 0; i < len; i++)
					{
						jerry_value_t key = jerry_get_property_by_index(keys_array, i);

						jerry_char_t buffer[256];
						jerry_value_t key_string = jerry_value_to_string(key);
						jerry_size_t copied_bytes = jerry_string_to_utf8_char_buffer(key_string, buffer, sizeof(buffer) - 1);
						buffer[copied_bytes] = '\0';

						char_t str[256];
						for (int i = 0; i < 256; i++) str[i] = buffer[i];

						jerry_value_t prop_value = jerry_get_property(arguments[1], key);
						if (jerry_value_is_string(prop_value))
						{
							jerry_char_t val[256];
							char_t str3[256];

							jerry_size_t copied_bytes = jerry_string_to_utf8_char_buffer(prop_value, val, sizeof(val) - 1);
							val[copied_bytes] = '\0';

							for (int i = 0; i < 256; i++) str3[i] = val[i];
							button.append_attribute(str) = str3;
						}
						else
						{
							button.append_attribute((const char*)buffer) = "";
						}


						jerry_release_value(key);
						jerry_release_value(key_string);
						jerry_release_value(prop_value);
					}

					jerry_release_value(keys_array);
					jerry_release_value(arg1);
					jerry_release_value(arg3);
				}
			}
		}
		else
		{
			cout << endl;
		}
		/* Return an "undefined" value to the JavaScript engine */
		return jerry_create_undefined();
	}
}


int main(int argc, char** args)
{
	//CUSTOM VARIABLES:
	//string path = "N:\\UNIVERSITY\\SEM 3 - Special Topic Mini Project\\Endpoint_(Azure_DevOps_Enygmator)\\EndpointBE_H\\src\\resources\\dummyDOMv2.json"; //place your own path here


	char hostname[] = "localhost";
	int port = 8184;

	// test request: http://localhost:8184/loadhtml?host=http%3A%2F%2Fwww.google.com&path=%2F
	// test request: http://localhost:8184/loadhtml?host=http%3A%2F%2Fcpp-httplib-server.yhirose.repl.co&path=%2Fhi

	// test request: http://localhost:8184/loadhtml?host=http%3A%2F%2Flocalhost:8184&path=%2Fdummies/html2
	//created at: https://apirequest.io/

	svr.Get("/loadhtml", [](const Request& req, Response& res) {
		string res_str = "{}";
		printf("GET /loadhtml\n");
		if (req.has_param("host") && req.has_param("path")) {
			string host = req.get_param_value("host");
			string path = req.get_param_value("path");

			printf("request: %s, %s\n", host.c_str(), path.c_str());
			Client cli(host.c_str());

			auto res = cli.Get(path.c_str());
			if (res->status == 200)
			{
				xml_parse_result result = dom.load_string(res->body.c_str());
				if (result)
				{
					json dom_json = all_elements_to_json(dom)[0];
					res_str = dom_json.dump(2);
				}
			}
		}

		res.set_content(res_str, "application/json");
	});

	//test request: http://localhost:8184/update

	svr.Get("/update", [](const Request&req, Response& res) {
		string res_str = "{}";
		printf("GET /update\n");

		json dom_json = all_elements_to_json(dom)[0];
		res_str = dom_json.dump(2);
		
		res.set_content(res_str, "application/json");
	});

	//test url: http://localhost:8184/click?func=add_button_to_dom

	svr.Get("/click", [](const Request&req, Response& res) {
		string res_str = "{}";
		printf("GET /click\n");
		if (!run_js)
		{
			res.set_content("{\"status\": \"JS is disabled in BE\"}", "application/json");
		}
		else if (!js_init)
		{
			res.set_content("{\"status\": \"JS file has not been run\"}", "application/json");
		}
		else
		{
			if (req.has_param("func")) {
				string func = req.get_param_value("func");

				printf("Click function: %s\n", func.c_str());
				string func_str = func + "();";
				int length = func_str.length();
				jerry_char_t* script = (jerry_char_t*)calloc(length, sizeof(jerry_char_t));
				if (script != NULL)
					for (int i = 0; i < length; i++)
					{
						script[i] = func_str[i];
					}

				bool run_ok = false;

				jerry_value_t parsed_func_code = jerry_parse(NULL, 0, script, length - 1, JERRY_PARSE_NO_OPTS);

				/* Check if there is any JS code parse error */
				if (!jerry_value_is_error(parsed_func_code))
				{
					/* Execute the parsed source code in the Global scope */
					jerry_value_t ret_value = jerry_run(parsed_func_code);

					/* Check the execution return value if there is any error */
					run_ok = !jerry_value_is_error(ret_value);

					/* Returned value must be freed */
					jerry_release_value(ret_value);
				}

				/* Parsed source code must be freed */
				jerry_release_value(parsed_func_code);

				res.set_content(run_ok ? "{\"status\":\"The function ran\"}" : "{\"status\":\"There was an error running the function\"}", "application/json");
			}
			else
			{
				res.set_content("{\"status\":\"You need to send the function name that has to be invoked\"}", "application/json");
			}
		}
	});

	// test request: http://localhost:8184/loadjs?host=http%3A%2F%2Flocalhost:8184&path=%2Fdummies%2Fjs1

	svr.Get("/loadjs", [](const Request& req, Response& res) {
		printf("GET /loadjs\n");
		if (!run_js)
		{
			res.set_content("{\"status\": \"JS is disabled in BE\"}", "application/json");
		}
		else if (js_init)
		{
			res.set_content("{\"status\": \"JS file has already been run\"}", "application/json");
		}
		else
		{
			if (req.has_param("host") && req.has_param("path")) {
				js_run_ok = false;
				string host = req.get_param_value("host");
				string path = req.get_param_value("path");
				printf("request: %s, %s\n", host.c_str(), path.c_str());
				Client cli(host.c_str());

				auto res = cli.Get(path.c_str());
				if (res->status == 200)
				{
					/* Initialize engine */
					jerry_init(JERRY_INIT_EMPTY);
					js_init = true;
					jerryx_handler_register_global((const jerry_char_t*)"print1", jerryx_handler_print);

					int length = res->body.length();
					jerry_char_t* script = (jerry_char_t*)calloc(length, sizeof(jerry_char_t));
					if (script != NULL)
						for (int i = 0; i < length; i++)
						{
							script[i] = res->body[i];
						}

					{
						/* Get the "global" object */
						jerry_value_t global_object = jerry_get_global_object();
						/* Create a "print" JS string */
						jerry_value_t property_name_print = jerry_create_string((const jerry_char_t*)"print");
						/* Create a function from a native C method (this function will be called from JS) */
						jerry_value_t property_value_func = jerry_create_external_function(print_handler);
						/* Add the "print" property with the function value to the "global" object */
						jerry_value_t set_result = jerry_set_property(global_object, property_name_print,property_value_func);
					
						/* Check if there was no error when adding the property (in this case it should never happen) */
						if (jerry_value_is_error(set_result)) {
							printf("Failed to add the 'print' property\n");
						}
					
						/* Release all jerry_value_t-s */
						jerry_release_value(set_result);
						jerry_release_value(property_value_func);
						jerry_release_value(property_name_print);
						jerry_release_value(global_object);
					}

					{
						/* Create an empty JS object */
						jerry_value_t object = jerry_create_object();
					
						/* Create a JS function object and wrap into a jerry value */
						jerry_value_t func_obj = jerry_create_external_function(XMLDOM::addElement);
					
						/* Set the native function as a property of the empty JS object */
						jerry_value_t prop_name = jerry_create_string((const jerry_char_t*)"addElement");
						jerry_release_value(jerry_set_property(object, prop_name, func_obj));
						jerry_release_value(prop_name);
						jerry_release_value(func_obj);
					
						/* Wrap the JS object (not empty anymore) into a jerry api value */
						jerry_value_t global_object = jerry_get_global_object();
					
						/* Add the JS object to the global context */
						prop_name = jerry_create_string((const jerry_char_t*)"XMLDOM");
						jerry_release_value(jerry_set_property(global_object, prop_name, object));
						jerry_release_value(prop_name);
						jerry_release_value(object);
						jerry_release_value(global_object);
					}

					/* Setup Global scope code */
					parsed_code = jerry_parse(NULL, 0, script, length - 1, JERRY_PARSE_NO_OPTS);

					/* Check if there is any JS code parse error */
					if (!jerry_value_is_error(parsed_code))
					{
						/* Execute the parsed source code in the Global scope */
						jerry_value_t ret_value = jerry_run(parsed_code);

						/* Check the execution return value if there is any error */
						js_run_ok = !jerry_value_is_error(ret_value);

						/* Returned value must be freed */
						jerry_release_value(ret_value);
					}
					else
					{
						cout << "There was an error in parsing the JS" << endl;
					}
				}
			}

			res.set_content("{\"status\": \"JS Code was run\"}", "application/json");
		}
	});

	svr.Get("/dummies/html2", [](const Request& req, Response& res) {
		string res_str = "<html><body><h1 style=\"margin-top:5px;\">Heading</h1></body></html>";
		ifstream fstr;
		string html_path = "N:\\UNIVERSITY\\SEM 3 - Special Topic Mini Project\\Endpoint_(Azure_DevOps_Enygmator)\\EndpointBE_H\\src\\resources\\dummyDOMv2.html"; //place your own path here
		fstr.open(html_path, ios::in);
		if (fstr) {
			res_str = "";
			while (fstr.good()) {
				res_str += fstr.get();
			}
		}

		res.set_content(res_str, "text/html");
	});

	svr.Get("/dummies/js2", [](const Request& req, Response& res) {
		string res_str = "var x = 3; var y = 4; var z = x * y; print(\"z = x * y = \"); print(z); print(\"\n\");";
		ifstream fstr;
		string js_path = "N:\\UNIVERSITY\\SEM 3 - Special Topic Mini Project\\Endpoint_(Azure_DevOps_Enygmator)\\EndpointBE_H\\src\\resources\\dummyDOMv2.js";; //place your own path here
		fstr.open(js_path, ios::in);
		if (fstr) {
			res_str = "";
			while (fstr.good()) {
				res_str += fstr.get();
			}
		}

		res.set_content(res_str, "text/javascript");
	});
	
	svr.Get("/stop", [](const Request& req, Response& res) {
		svr.stop();
	});

	cout << "the server should now be running!\nGo to http://" << hostname << ":" << port << "/loadhtml?host=http%3A%2F%2Flocalhost:8184&path=%2Fdummies/html2" << endl; //DevSkim: ignore DS137138 until 2020-12-31
	svr.listen(hostname, port);
	cout << "\nserver has stopped\n";

	if (run_js && js_init)
	{
		/* Parsed source code must be freed */
		jerry_release_value(parsed_code);

		/* Cleanup engine */
		jerry_cleanup();
	}

	return 0;
}
