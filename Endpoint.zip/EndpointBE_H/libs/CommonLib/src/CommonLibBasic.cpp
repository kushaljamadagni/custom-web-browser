#include "CommonLibBasic.hpp"

using namespace std;

void print_Lib_info()
{
	print_LibName();
}

void print_LibName()
{
	cout << "This a Common library for use in Endpoint_H Project" << endl;
}

int sum(int a, int b)
{
	return a + b;
}