#pragma once

void print_Lib_info();
int sum(int a,int b);