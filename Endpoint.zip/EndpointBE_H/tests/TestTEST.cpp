#include "gtest/gtest.h"
#include "CommonLib.hpp"

// Refer https://github.com/google/googletest/blob/master/googletest/docs/primer.md on writing GTests

using namespace std;

int main(int argc, char** argv)
{
	//Tried to implement custom argument: still trying
	/*
	const int number_of_custom_args = 3;
	string custom_args[number_of_custom_args] = { "example", "what", "crazy"};
	//You can give custom arguments to google test right here rather than using the command line

	//Set this value to false when you want to accept arguments from the CLI
	bool custom_arguments = true;
	if (custom_arguments)
	{
		argv = (char**)realloc(argv, argc + number_of_custom_args);
		for (int i = 0; i < number_of_custom_args; i++)
		{
			*(argv + argc + i) = (char*)&custom_args[i];
		}
		argc += number_of_custom_args;
		cout << "argc: " << argc << endl;
		cout << endl;
		for (int i = 0; i < argc; i++)
		{
			cout << argv[i] << endl;
		}
	}*/

	::testing::InitGoogleTest(&argc, argv);
	return RUN_ALL_TESTS();
}

TEST(TestCaseName, TestName) {
	EXPECT_EQ(1, 1);
	EXPECT_TRUE(true);

	//This is how you can capture standard output streams for debugging output.
	//This is a method that one should refrain from using and should rather
	//implement tests for functions, as printing is usually done from a main
	//function, unless the library itself prints without offering a function
	//to get an object as a return value.

	testing::internal::CaptureStdout();
	std::cout << "My test";
	std::string output = testing::internal::GetCapturedStdout();
	EXPECT_EQ(output, "My test");
}

TEST(CommonLibTest, sum_test)
{
	EXPECT_EQ(sum(2,3), 5);
}
