# Endpoint Backend Hydrogen (Type 1)

>NOTE: This Backend (BE) supports DOMv1 and DOMv2 BE-FE interfaces.

## Introduction

## Specifics of this project

### Build or meta-build systems

This project aims to have multiple build systems for various purposes.
So, we can use CMake or MSBuild as and when we wish, based on what we are comfortable with and so it's important to make sure that when files are added to a shared `src` folder, they should be added to both the build systems. (usually they are added to one of them automatically if the file is added using the solution explorer in Visual studio by right-clicking and adding an item to a project).

Some features may not work (or haven't been gotten to work yet) in either of the build systems.


> For now, CMake will be our build system of choice, which may change in the future. This means that a CMake build will always work unless specified otherwise.

### Testing framework

We will be using Google test as our testing framework in both the build systems.

### Compilers

We can customize the build systems to use various compilers. Our compiler of choice is Clang. But if we fail to compile any of the libraries using clang, then we will have to switch compilers. 

There is no protocol for if/when to switch to other compilers because it might cause other breaking changes in the code.

### Package manager

We will be using Conan as our package manager of choice and it's important that you have all the necessary packages installed on your system, so make sure to follow the build steps given below, without which your build may fail.

### Documentation

We will be using DocFX as our choice of Documentation generator/manager.

### Further details

> The documentation/ references for the above tools can be found in the documentation at azure devops wiki since those instructions can apply to multiple version of this project.

## Getting Started

Basic Installation Instructions:

- Clone repo and develop in the branch you are supposed to develop in.

## Build and Test


Visual studio watches all files that are build related for error, which may cause one build system to show no error in one file whereas another does because the required libraries may have been installed only in one build system and not in the other, etc.

Basically, one build system may compile while another may not if the required steps aren't followed.

### Using CMake

> You need to open the powershell in the `ConanDependencies` directory  by going to `~/EndpointBE_H/CMake_build/ConanDependencies/`.

First install all conan packages:

```ps
conan install . --profile ./ConanProfiles/x86_64_VS16_debug --install-folder "conanfiles/x64-Debug" --build missing
#The install folder can be anything; just mention it in the CMakeLists.txt
```

Help for building profiles can be found [here](https://docs.conan.io/en/latest/reference/profiles.html#profiles)

Then hit the Debug (Play) button in Visual studio. Make sure that the project selected to run is the one you intend to run. 
Also, first make sure to compile any libraries that you use, since they need to be compiled separately before the code that uses them (they have their own `CMakeLists.txt` in their respective folders inside of the `libs` directory).

e.g. Test executable: `(EndpointBE_H_CMake) TestEXE.exe (bin\TestEXE.exe)`, Test Unit Test: `(EndpointBE_H_CMake) TestTEST.exe (bin\TestTEST.exe)`

> Always make sure that "CMakeSettings.json" (a VS2019 file) accompanies only the "CMakeLists.txt" in "CMake_build" directory (which is the main - top level directory for cmake) and not any other "CMakeLists.txt" (in any other folder) because the rest of those are added as subdirectories to the (top level) "CMakeLists.txt".  
Otherwise you might end up building the wrong project leading to error which actually don't exist.

> Sometimes, you may find that run (play button) for a particular executable may not exist as an option, in which case you'll need to go to the "CMake targets view" using the "switch views" button in the solution explorer and right-click on the correct project and click "Generate Cache" and the issue should be resolved.

### Using MSBuild

> You need to open the powershell in the directory where the top level CMakeLists.txt exists, which in this case wrt the project directory is `~/EndpointBE_H/MSBuild_Projects/ConanDependencies/`.

First install all conan packages: 
>without doing this, your projects may fail to load; if they do then just install conan packages and then reload the projects

```ps
conan install . --profile ./ConanProfiles/x86_64_VS16_debug --install-folder "conanfiles/x64-Debug" --build missing
```

Following the installation of the packages, include them in the projects (in the solution) within which you wanna use them by going to the `property manager` window and right-click the project in which you'll be using the packages and select `add existing property sheet` and select the `Directory.Build.props` file which can be found at `~\EndpointBE_H\MSBuild_Projects\ConanDependencies`. 

After that select whichever project you want to run in the solution by going into the `solutions view` in the `solution explorer` and selecting the project as a `start up project` and clicking the play button (Launch debugger)


https://docs.conan.io/en/latest/integrations/build_system/msbuild.html

## Running the Backend (BE)

In order to run this BE to connect the Frontend (FE) and view webpages, you need t make sure you have a compatible frontend installed. You can check for compatibility in the README file of the frontend.

>NOTE: This Backend (BE) supports DOMv1 and DOMv2 BE-FE interfaces.

1. To run the BE, follow the setps mentioned in the previous section to install the necessary conan packages for CMake or MSBuild whichever you choose to use.

2. THen edit all the files where there are "path" variables like `html_path`, `js_path`, `path`, etc. to ensure that the paths which have been hardcoded according to the developer's computer are changed into paths on you computer so that the code can work on your computer too.

   >NOTE: Support for relative paths may come soon

3. After following the above steps, using Visual Studio (recommended) or visual studio code or the command line, you can run `BEv1_server` executable (DOMv1 supported) or `BEv2_server` executable (DOMv2 supported) according to what the FE supports. 

  Using CMake: The corresponding `CMakeLists.txt` file for both executables is in `~\EndpointBE_H\CMake_build` folder. IF you use Visual Studio to run it, you need to choose `(EndpointBE_H_CMake) BEv1_server.exe (bin\BEv1_server.exe)` in the `project configuration` dropdown before hitting the `play` (debug) button.

   Using MSBuild: You need to open the solution file `EndpointBE_H.sln` which is inside the directory `~\EndpointBE_H` and select `BEv1_server` or `BEv2_server` as the startup project (Based on whether you're using an FE running `DOMv1` or `DOMv2` respectively). You can do so by right-clicking on it following which you hit the debug (play) button to run the executable.

  >NOTE: When you click the stop server button in the FE, it might take  a few seconds to shutdown. CLicking Stop button again will cause an error to occur.

## Code Organisation

The code for both build systems is common as mentioned earlier, thus requiring you to make sure that the files are added to both systems via the VS2019 GUI of manually in the build system's configuration files.

### Source code

The main source code for the entire project (present version only) is stored in the `src` folder at `~/EndpointBE_H/`.

#### MSBuild Configuration

1. When you need to include headers from various locations in your project, add the locations to the `Additional Include Directories` value (using the edit button in the dropdown). This option can be found in `Properties` of the project under: `Configuration Properties -> C/C++ -> General`.  
Also, make sure to specify the include directories with respect to the solution directory. e.g. `$(SolutionDir)\libs\some_lib\include_dir`.

2. MAKE SURE you set the `output directory` value to `$(ProjectDir)$(Platform)\$(Configuration)\`.  
   > `output directory` can be found under `Configuration Properties -> General` in Properties.

### Tests

All tests related to this project are stored in the `tests` folder at `~/EndpointBE_H/`. Right now there are only test files from the Google Test framework.

### Libs

All tests related to this project are stored in the `libs` folder at `~/EndpointBE_H/`. These are libraries (packages of code) that aren't installed using Conan and instead are binaries (\*.a, \*dll, etc. ) or raw source code (\*.c, \*.cpp, etc.) supposed to be built either separately (and then linked at build or runtime) or must be built along with main executable (as is done in the `Commonlib` example).

NOTE: Dynamic linking hasn't been tried out yet. It may be implemented as needed or sometime in the future. (it's low priority)

> All above folders contain "CMakeLists.txt" file which aren't standalone and are instead part of the top level file. They have recipes related to that particular folder as part of the build system.
